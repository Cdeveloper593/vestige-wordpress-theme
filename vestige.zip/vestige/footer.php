<?php
/**
 * The footer: newsletter band, footer bar, mobile dock and the
 * slide-in cart drawer (rendered here so it exists on every page).
 *
 * @package Vestige
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<footer class="site-footer">
	<?php if ( ! is_front_page() ) : ?>
		<div class="newsletter-band vestige-plasma">
			<div class="wrap">
				<p class="eyebrow"><?php echo esc_html( (string) vestige_mod( 'vestige_newsletter_eyebrow', 'The Drop List' ) ); ?></p>
				<h2><?php echo esc_html( (string) vestige_mod( 'vestige_newsletter_heading', 'First access. No noise.' ) ); ?></h2>
				<form class="newsletter-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="vestige_newsletter" />
					<label class="screen-reader-text" for="vestige-nl-email"><?php esc_html_e( 'Email address', 'vestige' ); ?></label>
					<input id="vestige-nl-email" type="email" name="email" required placeholder="your@email.com" />
					<button type="submit" class="btn-primary"><?php esc_html_e( 'Join', 'vestige' ); ?></button>
				</form>
				<p class="newsletter-msg" role="status">
					<?php if ( isset( $_GET['vestige_subscribed'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display flag only. ?>
						<?php esc_html_e( 'You are on the list. Welcome to VESTIGE.', 'vestige' ); ?>
					<?php endif; ?>
				</p>
			</div>
		</div>
	<?php endif; ?>

	<?php if ( is_active_sidebar( 'footer-1' ) ) : ?>
		<div class="wrap footer-widgets">
			<?php dynamic_sidebar( 'footer-1' ); ?>
		</div>
	<?php endif; ?>

	<div class="wrap footer-bar">
		<p style="margin:0">
			<?php vestige_the_wordmark(); ?>
			<span class="tagline"><?php echo esc_html( (string) vestige_mod( 'vestige_footer_tagline', '— wear what remains' ) ); ?></span>
		</p>
		<?php if ( has_nav_menu( 'footer' ) ) : ?>
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'footer',
					'container'      => 'nav',
					'container_class' => 'footer-nav',
					'container_aria_label' => esc_attr__( 'Footer', 'vestige' ),
					'menu_class'     => 'footer-nav',
					'depth'          => 1,
				)
			);
			?>
		<?php else : ?>
			<nav class="footer-nav" aria-label="<?php esc_attr_e( 'Footer', 'vestige' ); ?>">
				<a href="<?php echo esc_url( vestige_shop_url() ); ?>"><?php esc_html_e( 'Shop', 'vestige' ); ?></a>
				<a href="<?php echo esc_url( vestige_checkout_url() ); ?>"><?php esc_html_e( 'Checkout', 'vestige' ); ?></a>
				<a href="#top"><?php esc_html_e( 'Back to top', 'vestige' ); ?></a>
			</nav>
		<?php endif; ?>
		<?php $vestige_socials = vestige_socials(); ?>
		<?php if ( $vestige_socials ) : ?>
			<div class="footer-socials">
				<?php foreach ( $vestige_socials as $vestige_social ) : ?>
					<a href="<?php echo esc_url( $vestige_social['url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $vestige_social['label'] ); ?></a>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
		<p style="margin:0"><?php echo esc_html( (string) vestige_mod( 'vestige_footer_note', '© ' . gmdate( 'Y' ) . ' Vestige. Wear what remains.' ) ); ?></p>
	</div>
</footer>

<div class="mobile-dock" aria-label="<?php esc_attr_e( 'Quick navigation', 'vestige' ); ?>">
	<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'vestige' ); ?></a>
	<a href="<?php echo esc_url( vestige_shop_url() ); ?>"><?php esc_html_e( 'Shop', 'vestige' ); ?></a>
	<button type="button" class="vestige-open-cart"><?php esc_html_e( 'Cart', 'vestige' ); ?></button>
</div>

<?php if ( class_exists( 'WooCommerce' ) && function_exists( 'vestige_render_cart_drawer' ) ) : ?>
	<?php vestige_render_cart_drawer(); ?>
<?php endif; ?>

<?php wp_footer(); ?>
</body>
</html>
