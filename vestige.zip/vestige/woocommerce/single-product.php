<?php
/**
 * Single product — a port of the source template's product page:
 * breadcrumbs, gallery with thumbnails on the left, and a sticky buy
 * column (eyebrow, display title, stars + stock line, price, the
 * native WooCommerce variation form — restyled by CSS and upgraded
 * to buttons/swatches by theme.js — details list). Description,
 * reviews and related products follow below.
 *
 * The add-to-cart form is WooCommerce's own
 * (woocommerce_template_single_add_to_cart), so variations, stock
 * rules and AJAX add-to-cart behave exactly as buyers expect.
 *
 * @package Vestige
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();
	global $product;

	$vestige_id       = $product->get_id();
	$vestige_badge    = (string) get_post_meta( $vestige_id, '_vestige_badge', true );
	$vestige_cats     = get_the_terms( $vestige_id, 'product_cat' );
	$vestige_cat_name = ( $vestige_cats && ! is_wp_error( $vestige_cats ) ) ? $vestige_cats[0]->name : '';
	$vestige_rating   = (float) $product->get_average_rating();
	$vestige_count    = function_exists( 'vestige_review_count' ) ? vestige_review_count( $product ) : (int) $product->get_review_count();
	$vestige_details  = function_exists( 'vestige_product_details' ) ? vestige_product_details( $vestige_id ) : array();
	$vestige_main_id  = $product->get_image_id();
	$vestige_gallery  = array_filter( array_merge( $vestige_main_id ? array( $vestige_main_id ) : array(), $product->get_gallery_image_ids() ) );
	$vestige_stock    = $product->get_stock_quantity();
	?>

	<main id="content" class="site-main">
		<div class="wrap product-wrap">
			<?php vestige_breadcrumbs(); ?>

			<div class="product-grid">
				<div class="product-gallery">
					<div class="ph product-main-img">
						<?php
						if ( $vestige_main_id ) {
							echo wp_get_attachment_image( $vestige_main_id, 'large', false, array( 'id' => 'vestige-main-image', 'alt' => esc_attr( $product->get_name() ) ) );
						} else {
							echo wc_placeholder_img( 'large' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Woo placeholder HTML.
						}
						?>
					</div>
					<?php if ( count( $vestige_gallery ) > 1 ) : ?>
						<div class="product-thumbs" role="group" aria-label="<?php esc_attr_e( 'Choose product image', 'vestige' ); ?>">
							<?php foreach ( $vestige_gallery as $vestige_i => $vestige_att_id ) : ?>
								<?php
								$vestige_full = wp_get_attachment_image_url( $vestige_att_id, 'large' );
								?>
								<button type="button" class="product-thumb ph<?php echo 0 === $vestige_i ? ' is-active' : ''; ?>"
									data-full="<?php echo esc_url( $vestige_full ); ?>"
									aria-pressed="<?php echo 0 === $vestige_i ? 'true' : 'false'; ?>"
									aria-label="<?php echo esc_attr( sprintf( /* translators: %d: image number. */ __( 'View image %d', 'vestige' ), $vestige_i + 1 ) ); ?>">
									<?php echo wp_get_attachment_image( $vestige_att_id, 'thumbnail', false, array( 'alt' => '' ) ); ?>
								</button>
							<?php endforeach; ?>
						</div>
						<p class="product-gallery-tip"><?php esc_html_e( 'Pick a thumbnail to change the view.', 'vestige' ); ?></p>
					<?php endif; ?>
				</div>

				<div class="product-buy">
					<p class="eyebrow">
						<?php echo esc_html( $vestige_cat_name ); ?>
						<?php echo '' !== $vestige_badge ? ' — ' . esc_html( $vestige_badge ) : ''; ?>
					</p>
					<h1 class="product-title"><?php the_title(); ?></h1>

					<p class="product-rating-line">
						<?php if ( $vestige_rating > 0 ) : ?>
							<span aria-label="<?php echo esc_attr( sprintf( /* translators: 1: rating, 2: review count. */ __( 'Rated %1$s out of 5 from %2$d reviews', 'vestige' ), $vestige_rating, $vestige_count ) ); ?>">
								<?php echo vestige_stars_html( $vestige_rating ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- star characters only. ?>
								<span class="rating-num"><?php echo esc_html( number_format_i18n( $vestige_rating, 1 ) ); ?> · <?php echo esc_html( sprintf( /* translators: %d: review count. */ _n( '%d review', '%d reviews', $vestige_count, 'vestige' ), $vestige_count ) ); ?></span>
							</span>
						<?php endif; ?>
						<?php if ( $product->is_in_stock() ) : ?>
							<span class="stock-line<?php echo ( null !== $vestige_stock && $vestige_stock <= 12 ) ? ' is-low' : ''; ?>">
								<?php
								if ( null !== $vestige_stock && $vestige_stock <= 12 ) {
									printf( /* translators: %d: stock quantity. */ esc_html__( 'Only %d left', 'vestige' ), (int) $vestige_stock );
								} else {
									esc_html_e( 'In stock', 'vestige' );
								}
								?>
							</span>
						<?php else : ?>
							<span class="stock-line is-low"><?php esc_html_e( 'Out of stock', 'vestige' ); ?></span>
						<?php endif; ?>
					</p>

					<p class="product-price"><?php echo wp_kses_post( $product->get_price_html() ); ?></p>

					<?php if ( $product->get_short_description() ) : ?>
						<div class="product-short"><?php echo wp_kses_post( wpautop( $product->get_short_description() ) ); ?></div>
					<?php endif; ?>

					<div class="product-form">
						<?php woocommerce_template_single_add_to_cart(); ?>
						<?php
						// Colour swatch data for theme.js (slug → hex), from
						// the pa_colour term meta. Harmless without JS: the
						// native selects stay fully functional.
						$vestige_colour_terms = get_terms(
							array(
								'taxonomy'   => 'pa_colour',
								'hide_empty' => false,
							)
						);
						if ( $vestige_colour_terms && ! is_wp_error( $vestige_colour_terms ) ) {
							$vestige_map = array();
							foreach ( $vestige_colour_terms as $vestige_term ) {
								$vestige_hex = function_exists( 'vestige_colour_hex' ) ? vestige_colour_hex( $vestige_term->term_id ) : '';
								if ( $vestige_hex ) {
									$vestige_map[ $vestige_term->slug ] = $vestige_hex;
								}
							}
							if ( $vestige_map ) {
								echo '<script type="application/json" id="vestige-colour-map">' . wp_json_encode( $vestige_map ) . '</script>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON of sanitized hex colours.
							}
						}
						?>
					</div>

					<?php if ( $vestige_details ) : ?>
						<div class="product-details">
							<h2 class="details-title"><?php esc_html_e( 'Details', 'vestige' ); ?></h2>
							<ul>
								<?php foreach ( $vestige_details as $vestige_detail ) : ?>
									<li><?php echo esc_html( $vestige_detail ); ?></li>
								<?php endforeach; ?>
							</ul>
						</div>
					<?php endif; ?>

					<p class="product-meta-line">
						<?php
						printf(
							/* translators: %s: product SKU. */
							esc_html__( 'SKU: %s', 'vestige' ),
							esc_html( $product->get_sku() ? $product->get_sku() : '—' )
						);
						?>
					</p>
				</div>
			</div>

			<?php if ( $product->get_description() ) : ?>
				<section class="product-description">
					<h2 class="display" style="font-size:2rem"><?php esc_html_e( 'The story', 'vestige' ); ?></h2>
					<div class="entry-content"><?php echo wp_kses_post( wpautop( $product->get_description() ) ); ?></div>
				</section>
			<?php endif; ?>

			<section class="product-reviews">
				<?php comments_template( 'single-product-reviews.php' ); ?>
			</section>

			<?php woocommerce_output_related_products(); ?>
		</div>
	</main>

	<?php
endwhile;

get_footer();
