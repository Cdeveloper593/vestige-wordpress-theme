<?php
/**
 * Vestige theme bootstrap.
 *
 * Loads the modular includes in /inc. Keep this file thin: every feature
 * lives in its own file so buyers (and child themes) can follow along.
 *
 * @package Vestige
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'VESTIGE_VERSION', '1.0.0' );

$vestige_includes = array(
	'inc/setup.php',
	'inc/helpers.php',
	'inc/template-tags.php',
	'inc/enqueue.php',
	'inc/customizer.php',
	'inc/customizer-css.php',
	'inc/patterns.php',
	'inc/woocommerce.php',
	'inc/demo-import.php',
);

foreach ( $vestige_includes as $vestige_file ) {
	$vestige_path = get_template_directory() . '/' . $vestige_file;
	if ( file_exists( $vestige_path ) ) {
		require_once $vestige_path;
	}
}
unset( $vestige_includes, $vestige_file, $vestige_path );
