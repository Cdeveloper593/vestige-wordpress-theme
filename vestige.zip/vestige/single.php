<?php
/**
 * Single blog post.
 *
 * @package Vestige
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="content" class="site-main">
	<div class="wrap content-wrap">
		<?php
		while ( have_posts() ) :
			the_post();
			?>
			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
				<header class="entry-header" style="margin-bottom:2rem">
					<p class="entry-meta"><?php vestige_posted_on(); ?></p>
					<h1 class="entry-title"><?php the_title(); ?></h1>
				</header>
				<?php if ( has_post_thumbnail() ) : ?>
					<div class="ph" style="aspect-ratio:16/9;margin-bottom:2rem"><?php the_post_thumbnail( 'large' ); ?></div>
				<?php endif; ?>
				<div class="entry-content">
					<?php
					the_content();
					wp_link_pages(
						array(
							'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'vestige' ),
							'after'  => '</div>',
						)
					);
					?>
				</div>
				<?php the_tags( '<p class="entry-meta" style="margin-top:2rem">', ' · ', '</p>' ); ?>
			</article>

			<nav class="post-nav" aria-label="<?php esc_attr_e( 'Post navigation', 'vestige' ); ?>">
				<span><?php previous_post_link( '%link', '← %title' ); ?></span>
				<span><?php next_post_link( '%link', '%title →' ); ?></span>
			</nav>

			<?php
			if ( comments_open() || get_comments_number() ) {
				comments_template();
			}
		endwhile;
		?>
	</div>
</main>

<?php
get_footer();
