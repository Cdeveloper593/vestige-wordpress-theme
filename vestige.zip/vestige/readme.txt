=== Vestige ===
Contributors: ceriumwebdevelopment
Tags: e-commerce, woocommerce, one-column, custom-colors, custom-logo, custom-menu, featured-images, theme-options, translation-ready, blog, block-patterns
Requires at least: 6.3
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A dark editorial WooCommerce theme for fashion labels and concept stores — drag-and-drop homepage, filterable shop, AJAX cart drawer.

== Description ==

Vestige turns a WordPress + WooCommerce install into a dark, editorial fashion store: giant Anton headlines, bone-on-ink contrast, a vermilion accent, and motion that feels like a lookbook — smooth scrolling, scroll reveals, a marquee, and product cards that swap images and glow under the cursor.

Underneath the show, Vestige is a plain, well-behaved WordPress theme:

* A **drag-and-drop homepage**: every section (hero, marquee, featured products, categories, story, field notes, reviews, newsletter) is a native Gutenberg **block pattern**. Reorder, duplicate, delete and edit them in the block editor — no page-builder plugin needed, and no paid plugin anywhere in this theme.
* A **real store**: products are WooCommerce variable products (Size / Colour variations with their own stock), the shop filters by search, category, max price and sort, and checkout is WooCommerce's own.
* An **AJAX cart drawer** with quantity steppers and a free-shipping progress meter (free over $200, $12 flat rate below — set by the demo import's shipping zone).
* A **Customizer panel** for the global brand: announcement bar, colours (ink / bone / accent), footer, socials, and the default copy the patterns are seeded with.
* A one-click **demo import** (Appearance → Vestige Demo) that builds the whole demo store: 14 products, 5 categories, attributes, reviews, 34 media-library images, pages and menus. Idempotent and backfill-safe.
* Fully responsive, reduced-motion aware, and readable with JavaScript off. The animation layer (GSAP + Lenis, bundled locally) is progressive enhancement only.

== Installation ==

1. Install and activate the free **WooCommerce** plugin (Plugins → Add New).
2. In your WordPress dashboard, go to Appearance → Themes → Add New → Upload Theme.
3. Upload `vestige.zip` and activate the theme.
4. Go to Appearance → Vestige Demo and run the demo import once. It creates the demo store, sets a static homepage and wires up the WooCommerce pages.
5. Make it yours: edit the Home page in the block editor (drag-and-drop), replace products under Products, and set your brand under Appearance → Customize → Vestige.
6. Add a real payment gateway under WooCommerce → Settings → Payments when you are ready to take money.

== Frequently Asked Questions ==

= Do I need any paid plugins? =
No. The theme needs only WordPress and the free WooCommerce plugin. Page editing uses the built-in block editor; cart and checkout use WooCommerce's own blocks/shortcodes. Nothing is gated behind a pro plugin.

= How do I edit the homepage? =
Pages → Home. Every section is a group of blocks (they were inserted from the Vestige block patterns). Drag sections to reorder them, click any text or image to change it, or add more sections from the pattern inserter (the "Vestige" category).

= How do I add a product? =
Products → Add New. For sizes/colours, create a variable product: add the Size and Colour attributes (Products → Attributes), tick "Used for variations", and generate variations. Use the "Vestige — Badge & Details" box on the product screen for the card badge chip and the details bullet list.

= How do I change the colours? =
Appearance → Customize → Vestige → Colours. Ink, Bone and Accent drive the whole theme through CSS variables, including the patterns and the shop.

= Where does the newsletter form go? =
Signups are stored in WordPress (an option you can export from the database / via the admin) — no third-party service is contacted. The buyer guide (docs/documentation.html) shows how to point the handler at a mailing-list provider instead.

= Does it work with Elementor? =
Yes — pages can be built with the free Elementor plugin if you prefer it; the theme's header, footer, shop and product templates stay in charge of the store chrome. It is optional: the built-in block editor covers the homepage out of the box.

== Changelog ==

= 1.0.0 =
* Initial release: block-pattern homepage, WooCommerce shop/product/cart-drawer integration, Customizer brand panel, one-click demo store import.
