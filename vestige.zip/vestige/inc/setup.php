<?php
/**
 * Theme setup: supports, menus, image sizes, editor styles.
 *
 * @package Vestige
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register theme defaults and supports.
 */
function vestige_setup() {
	load_theme_textdomain( 'vestige', get_template_directory() . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'editor-styles' );
	add_theme_support( 'wp-block-styles' );
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 80,
			'width'       => 400,
			'flex-height' => true,
			'flex-width'  => true,
			'header-text' => array( 'site-title' ),
		)
	);
	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' )
	);
	add_theme_support(
		'custom-background',
		array( 'default-color' => '101010' )
	);

	// WooCommerce: full support, product gallery lightbox / zoom / slider.
	add_theme_support(
		'woocommerce',
		array(
			'thumbnail_image_width'         => 600,
			'single_thumbnail_image_width'  => 900,
			'product_grid'                  => array(
				'default_rows'    => 4,
				'default_columns' => 3,
			),
		)
	);
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );

	register_nav_menus(
		array(
			'primary' => esc_html__( 'Primary Menu (overlay)', 'vestige' ),
			'footer'  => esc_html__( 'Footer Menu', 'vestige' ),
		)
	);

	add_image_size( 'vestige-card', 800, 1000, true );   // 4:5 product cards.
	add_image_size( 'vestige-hero', 1000, 1250, true );  // 4:5 hero media.
	add_image_size( 'vestige-wide', 1200, 675, true );   // 16:9 story cards.

	if ( ! isset( $GLOBALS['content_width'] ) ) {
		$GLOBALS['content_width'] = 1280;
	}
}
add_action( 'after_setup_theme', 'vestige_setup', 0 );

/**
 * Flush rewrite rules on activation so shop / product URLs resolve.
 */
function vestige_after_switch_theme() {
	flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'vestige_after_switch_theme' );

/**
 * Editor stylesheet so the block editor roughly matches the front end.
 *
 * @param array $css Array of editor CSS URLs.
 * @return array
 */
function vestige_editor_styles( $css ) {
	$css[] = 'assets/css/editor.css';
	return $css;
}
add_filter( 'editor_stylesheets', 'vestige_editor_styles' );

/**
 * Register the footer widget area (kept minimal — the theme is pattern-led).
 */
function vestige_widgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer Widgets', 'vestige' ),
			'id'            => 'footer-1',
			'description'   => esc_html__( 'Optional widgets shown above the footer bar.', 'vestige' ),
			'before_widget' => '<section class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		)
	);
}
add_action( 'widgets_init', 'vestige_widgets_init' );
