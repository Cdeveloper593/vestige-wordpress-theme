<?php
/**
 * Styles and scripts: Google Fonts, base styles, WooCommerce styles,
 * and the motion layer (bundled GSAP + Lenis — free libraries, loaded
 * locally, never from a CDN).
 *
 * @package Vestige
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Version string based on file modification time (cache-busting for
 * buyers who edit CSS/JS directly), falling back to the theme version.
 *
 * @param string $relative_path Path relative to the theme root.
 * @return string
 */
function vestige_asset_version( $relative_path ) {
	$file = get_template_directory() . '/' . ltrim( $relative_path, '/' );
	if ( file_exists( $file ) ) {
		return (string) filemtime( $file );
	}
	return VESTIGE_VERSION;
}

/**
 * Enqueue front-end assets.
 */
function vestige_enqueue_assets() {
	$uri = get_template_directory_uri();

	wp_enqueue_style(
		'vestige-fonts',
		'https://fonts.googleapis.com/css2?family=Anton&family=Archivo:wght@400;500;600;700&display=swap',
		array(),
		null
	);

	wp_enqueue_style(
		'vestige-style',
		get_stylesheet_uri(),
		array( 'vestige-fonts' ),
		vestige_asset_version( 'style.css' )
	);

	if ( class_exists( 'WooCommerce' ) ) {
		wp_enqueue_style(
			'vestige-woocommerce',
			$uri . '/assets/css/woocommerce.css',
			array( 'vestige-style' ),
			vestige_asset_version( 'assets/css/woocommerce.css' )
		);
	}

	// Motion layer — progressive enhancement only. theme.js guards every
	// feature so the site is complete with these files missing/blocked.
	wp_enqueue_script(
		'vestige-gsap',
		$uri . '/assets/js/vendor/gsap.min.js',
		array(),
		'3.12.5',
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);
	wp_enqueue_script(
		'vestige-lenis',
		$uri . '/assets/js/vendor/lenis.min.js',
		array(),
		'1.1.18',
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);
	wp_enqueue_script(
		'vestige-scrolltrigger',
		$uri . '/assets/js/vendor/ScrollTrigger.min.js',
		array( 'vestige-gsap' ),
		'3.12.5',
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);
	wp_enqueue_script(
		'vestige-theme',
		$uri . '/assets/js/theme.js',
		array( 'vestige-gsap', 'vestige-scrolltrigger', 'vestige-lenis' ),
		vestige_asset_version( 'assets/js/theme.js' ),
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);

	wp_localize_script(
		'vestige-theme',
		'vestigeTheme',
		array(
			'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
			'nonce'     => wp_create_nonce( 'vestige_cart' ),
			'threshold' => vestige_free_shipping_threshold(),
			'i18n'      => array(
				'freeUnlocked' => __( 'Free shipping unlocked', 'vestige' ),
				/* translators: %s: amount still needed for free shipping. */
				'addMore'      => __( 'Add %s more for free shipping', 'vestige' ),
			),
		)
	);

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'vestige_enqueue_assets' );

/**
 * Add a tiny inline script in the head that flags JS availability, so
 * reveal animations start hidden ONLY when JS can reveal them.
 * Content is fully visible with JavaScript disabled.
 */
function vestige_js_flag() {
	echo "<script>document.documentElement.classList.add('js');</script>\n";
}
add_action( 'wp_head', 'vestige_js_flag', 1 );
