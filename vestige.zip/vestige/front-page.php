<?php
/**
 * Front page.
 *
 * The homepage is a normal WordPress page whose content is the
 * Vestige block patterns (assembled by the demo import, or added by
 * the buyer from the pattern inserter) — fully drag-and-drop in the
 * block editor. If the front page has no content yet, the theme
 * renders the patterns directly as a fallback so a fresh install
 * still shows the full design.
 *
 * @package Vestige
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="content" class="site-main">
	<?php
	if ( have_posts() ) {
		while ( have_posts() ) {
			the_post();
			$vestige_content = get_the_content();
			if ( '' !== trim( wp_strip_all_tags( $vestige_content ) ) || has_block( 'image', get_post() ) || has_block( 'shortcode', get_post() ) ) {
				the_content();
			} else {
				// Fallback: render the patterns so the design shows
				// even before the demo import / page editing.
				echo do_blocks( vestige_home_content() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- block markup built from escaped parts.
			}
		}
	} else {
		echo do_blocks( vestige_home_content() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- block markup built from escaped parts.
	}
	?>
</main>

<?php
get_footer();
