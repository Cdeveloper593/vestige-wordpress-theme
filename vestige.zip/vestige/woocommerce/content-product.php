<?php
/**
 * Product card — a port of the source template's ProductCard:
 * 4:5 image that swaps to the second gallery image on hover, badge
 * chip (top-left), "Only N left" chip when stock ≤ 12, category
 * eyebrow, name, stars + rating (count), price with compare-at strike
 * (Woo's sale price markup). Whole card is one link, like the source.
 *
 * @package Vestige
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $product;

if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}

$vestige_id        = $product->get_id();
$vestige_gallery   = $product->get_gallery_image_ids();
$vestige_hover_id  = ! empty( $vestige_gallery ) ? (int) $vestige_gallery[0] : 0;
$vestige_badge     = (string) get_post_meta( $vestige_id, '_vestige_badge', true );
$vestige_cats      = get_the_terms( $vestige_id, 'product_cat' );
$vestige_cat_name  = ( $vestige_cats && ! is_wp_error( $vestige_cats ) ) ? $vestige_cats[0]->name : '';
$vestige_rating    = (float) $product->get_average_rating();
$vestige_count     = function_exists( 'vestige_review_count' ) ? vestige_review_count( $product ) : (int) $product->get_review_count();
$vestige_stock_qty = $product->managing_stock() ? $product->get_stock_quantity() : null;
?>
<li <?php wc_product_class( 'vestige-card', $product ); ?>>
	<a href="<?php echo esc_url( get_permalink( $vestige_id ) ); ?>" class="vestige-card__link">
		<div class="vestige-card__media ph">
			<?php echo $product->get_image( 'vestige-card', array( 'class' => 'vestige-card__img' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Woo image HTML. ?>
			<?php if ( $vestige_hover_id ) : ?>
				<?php echo wp_get_attachment_image( $vestige_hover_id, 'vestige-card', false, array( 'class' => 'vestige-card__img vestige-card__img--hover', 'alt' => '', 'aria-hidden' => 'true' ) ); ?>
			<?php endif; ?>
			<?php if ( '' !== $vestige_badge ) : ?>
				<span class="vestige-chip vestige-chip--badge"><?php echo esc_html( $vestige_badge ); ?></span>
			<?php endif; ?>
			<?php if ( null !== $vestige_stock_qty && $vestige_stock_qty <= 12 && $vestige_stock_qty > 0 ) : ?>
				<span class="vestige-chip vestige-chip--stock">
					<?php
					printf(
						/* translators: %d: stock quantity. */
						esc_html__( 'Only %d left', 'vestige' ),
						(int) $vestige_stock_qty
					);
					?>
				</span>
			<?php endif; ?>
		</div>
		<div class="vestige-card__body">
			<?php if ( '' !== $vestige_cat_name ) : ?>
				<p class="vestige-card__cat"><?php echo esc_html( $vestige_cat_name ); ?></p>
			<?php endif; ?>
			<h3 class="vestige-card__title"><?php echo esc_html( $product->get_name() ); ?></h3>
			<?php if ( $vestige_rating > 0 ) : ?>
				<p class="vestige-card__rating" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: average rating. */ __( 'Rated %s out of 5', 'vestige' ), $vestige_rating ) ); ?>">
					<?php echo vestige_stars_html( $vestige_rating ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- star characters only. ?>
					<span class="rating-num"><?php echo esc_html( number_format_i18n( $vestige_rating, 1 ) ); ?> (<?php echo esc_html( number_format_i18n( $vestige_count ) ); ?>)</span>
				</p>
			<?php endif; ?>
			<p class="vestige-card__price"><?php echo wp_kses_post( $product->get_price_html() ); ?></p>
		</div>
	</a>
</li>
