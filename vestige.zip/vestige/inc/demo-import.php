<?php
/**
 * One-click demo import: Appearance → Vestige Demo.
 *
 * Builds the full VESTIGE demo store:
 *   - the 34 demo images, sideloaded into the media library
 *   - Size + Colour product attributes (Colour terms carry swatch hexes)
 *   - the 5 product categories
 *   - the 14 source products as VARIABLE products (variations with
 *     price / sale price / stock), galleries, featured flags, badge
 *     and details meta, and their approved reviews with ratings
 *   - a Home page assembled from the theme's block patterns (with
 *     media-library image URLs), Shop / Cart / Checkout / My Account
 *     pages wired into WooCommerce, menus, and Woo settings
 *     (USD, reviews on, free shipping ≥ $200 + $12 flat rate)
 *
 * Everything is idempotent and backfill-safe: existing items are
 * matched by slug and skipped, missing pieces are repaired, and
 * nothing a buyer has edited is overwritten. Nothing runs
 * automatically — only from this admin page.
 *
 * Product data mirrors src/data/products.ts of the source template.
 *
 * @package Vestige
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Review pool from the source data (index-referenced per product).
 *
 * @return array<int, array<string,mixed>>
 */
function vestige_demo_review_pool() {
	return array(
		array( 'author' => 'Mara J.', 'rating' => 5, 'title' => 'Heavier, better, honest', 'body' => 'You can feel the fabric weight the second you pick it up. Cut is exactly as pictured — boxy where it should be, clean at the hem.', 'date' => '2026-10-18' ),
		array( 'author' => 'Devon K.', 'rating' => 5, 'title' => 'Wears like armour', 'body' => 'Third VESTIGE piece I own. Survived a month of daily wear without losing shape. Sizing runs true — take your usual.', 'date' => '2026-09-30' ),
		array( 'author' => 'Anaïs R.', 'rating' => 4, 'title' => 'Beautiful, minimal, warm', 'body' => 'The colour is deeper in person. Docked one star because delivery took six days, but the garment itself is flawless.', 'date' => '2026-10-02' ),
		array( 'author' => 'Tomás E.', 'rating' => 5, 'title' => 'Zero logos, all presence', 'body' => 'Exactly the point of this label. People ask where it is from constantly. Stitching and hardware feel a tier above the price.', 'date' => '2026-08-21' ),
		array( 'author' => 'June P.', 'rating' => 4, 'title' => 'Structured and sharp', 'body' => 'Holds its silhouette all day. Slightly long in the sleeve for me — the size guide is accurate, so read it before ordering.', 'date' => '2026-10-27' ),
		array( 'author' => 'Felix W.', 'rating' => 5, 'title' => 'Bought a second one', 'body' => 'Rarely do this. The first one got so many comments I ordered the other colourway before it sold out.', 'date' => '2026-09-12' ),
	);
}

/**
 * The 14 demo products — a faithful copy of the source data file.
 * 'reviews' holds indexes into vestige_demo_review_pool().
 * Image entries are file names inside assets/demo/.
 *
 * @return array<int, array<string,mixed>>
 */
function vestige_demo_products() {
	$apparel = array( 'XS', 'S', 'M', 'L', 'XL' );
	$shoes   = array( '40', '41', '42', '43', '44', '45' );
	$inkbone = array(
		array( 'name' => 'Ink', 'hex' => '#101010' ),
		array( 'name' => 'Bone', 'hex' => '#EDE8E0' ),
	);
	return array(
		array(
			'slug' => 'relic-leather-jacket', 'name' => 'Relic Leather Jacket', 'price' => 485, 'compareAt' => 560,
			'description' => 'A cropped, boxy jacket cut from full-grain aniline leather that breaks in like a second skin. No visible branding — just weight, drape and a vermilion interior stitch that only shows when you move.',
			'details' => array( 'Full-grain aniline leather', 'Corozo buttons, gunmetal zip', 'Quilted vermilion lining', 'Made in limited runs of 200' ),
			'category' => 'Outerwear', 'sizes' => $apparel, 'colours' => $inkbone, 'rating' => 4.9, 'reviewCount' => 212, 'reviews' => array( 1, 3, 5 ),
			'badge' => 'Icon', 'stock' => 14, 'featured' => true,
			'images' => array( '1551028719-00167b16eac5.jpg', '1483985988355-763728e1935b.jpg', '1523381210434-271e8be1f52b.jpg' ),
		),
		array(
			'slug' => 'monolith-wool-coat', 'name' => 'Monolith Wool Coat', 'price' => 420, 'compareAt' => 0,
			'description' => 'Floor-skimming double-faced wool with a sculpted shoulder and a single hidden closure. Cut oversized on purpose — it is the whole outfit.',
			'details' => array( 'Double-faced Italian wool', 'Hidden single closure', 'Two interior pockets', 'Oversized editorial cut' ),
			'category' => 'Outerwear', 'sizes' => $apparel, 'colours' => $inkbone, 'rating' => 4.8, 'reviewCount' => 148, 'reviews' => array( 2, 0 ),
			'badge' => 'New', 'stock' => 9, 'featured' => true,
			'images' => array( '1539109136881-3be0616acf4b.jpg', '1445205170230-053b83016050.jpg', '1490481651871-ab68de25d43d.jpg' ),
		),
		array(
			'slug' => 'foundation-heavy-tee', 'name' => 'Foundation Heavy Tee', 'price' => 95, 'compareAt' => 120,
			'description' => '240gsm organic cotton with a ribbed collar that refuses to sag. The tee other tees are measured against — dense, matte, and cut square.',
			'details' => array( '240gsm organic cotton', 'Ribbed anti-sag collar', 'Side-seamed, boxy cut', 'Garment-dyed' ),
			'category' => 'Essentials', 'sizes' => $apparel,
			'colours' => array_merge( $inkbone, array( array( 'name' => 'Vermilion', 'hex' => '#FF4D00' ) ) ),
			'rating' => 4.9, 'reviewCount' => 864, 'reviews' => array( 0, 5, 1 ),
			'badge' => 'Bestseller', 'stock' => 120, 'featured' => true,
			'images' => array( '1521572163474-6864f9cf17ab.jpg', '1576566588028-4147f3842f27.jpg', '1503342217505-b0a15ec3261c.jpg' ),
		),
		array(
			'slug' => 'axis-wide-denim', 'name' => 'Axis Wide Denim', 'price' => 185, 'compareAt' => 0,
			'description' => '14oz Japanese selvedge in a wide, straight leg that stacks perfectly over boots or breaks clean over sneakers. Fades are earned, never printed.',
			'details' => array( '14oz Japanese selvedge', 'Wide straight leg', 'Chain-stitched hems', 'Button fly' ),
			'category' => 'Tailoring', 'sizes' => array( '28', '30', '32', '34', '36' ), 'colours' => $inkbone, 'rating' => 4.7, 'reviewCount' => 231, 'reviews' => array( 3, 4 ),
			'badge' => '', 'stock' => 42, 'featured' => false,
			'images' => array( '1542272604-787c3835535d.jpg', '1541099649105-f69ad21f3246.jpg', '1434389677669-e08b4cac3105.jpg' ),
		),
		array(
			'slug' => 'signal-runner', 'name' => 'Signal Runner', 'price' => 240, 'compareAt' => 0,
			'description' => 'A sculpted runner in matte technical mesh and suede, finished with a single vermilion heel tab. Built for cities, styled for galleries.',
			'details' => array( 'Technical mesh + suede upper', 'Dual-density foam sole', 'Reflective heel tab', 'Vegan lining' ),
			'category' => 'Footwear', 'sizes' => $shoes, 'colours' => $inkbone, 'rating' => 4.8, 'reviewCount' => 317, 'reviews' => array( 5, 2, 0 ),
			'badge' => 'New', 'stock' => 58, 'featured' => true,
			'images' => array( '1549298916-b41d501d3772.jpg', '1595950653106-6c9ebd614d3a.jpg', '1600185365483-26d7a4cc7519.jpg' ),
		),
		array(
			'slug' => 'court-low-sneaker', 'name' => 'Court Low Sneaker', 'price' => 195, 'compareAt' => 230,
			'description' => 'A minimal court profile in full-grain white leather on a natural gum sole. No logos on the upper — the silhouette does the talking.',
			'details' => array( 'Full-grain leather upper', 'Natural gum cupsole', 'Leather-lined interior', 'Hand-finished in Portugal' ),
			'category' => 'Footwear', 'sizes' => $shoes,
			'colours' => array( array( 'name' => 'Bone', 'hex' => '#EDE8E0' ), array( 'name' => 'Ink', 'hex' => '#101010' ) ),
			'rating' => 4.9, 'reviewCount' => 402, 'reviews' => array( 1, 0 ),
			'badge' => '', 'stock' => 73, 'featured' => false,
			'images' => array( '1560769629-975ec94e6a86.jpg', '1543163521-1bf539c55dd2.jpg', '1556306535-0f09a537f0a3.jpg' ),
		),
		array(
			'slug' => 'cargo-day-pack', 'name' => 'Cargo Day Pack', 'price' => 210, 'compareAt' => 0,
			'description' => 'A 22-litre pack in ballistic nylon with magnetic hardware and a padded 16-inch laptop sleeve. Carries a day, looks like a sculpture.',
			'details' => array( 'Ballistic nylon shell', 'Magnetic buckle hardware', 'Padded 16" laptop sleeve', '22L capacity' ),
			'category' => 'Objects', 'sizes' => array( 'One Size' ), 'colours' => $inkbone, 'rating' => 4.7, 'reviewCount' => 129, 'reviews' => array( 4, 3 ),
			'badge' => '', 'stock' => 26, 'featured' => false,
			'images' => array( '1553062407-98eeb64c6a62.jpg', '1483985988355-763728e1935b.jpg', '1441986300917-64674bd600d8.jpg' ),
		),
		array(
			'slug' => 'eclipse-frame-glasses', 'name' => 'Eclipse Frame', 'price' => 150, 'compareAt' => 0,
			'description' => 'Hand-polished bio-acetate frames with nylon polarised lenses. Square, dark, and deliberately unbranded.',
			'details' => array( 'Bio-acetate frame', 'Polarised nylon lenses', '100% UV protection', 'Includes hard case' ),
			'category' => 'Objects', 'sizes' => array( 'One Size' ), 'colours' => $inkbone, 'rating' => 4.6, 'reviewCount' => 88, 'reviews' => array( 2, 5 ),
			'badge' => '', 'stock' => 51, 'featured' => false,
			'images' => array( '1511499767150-a48a237f0083.jpg', '1571945153237-4929e783af4a.jpg', '1556306535-0f09a537f0a3.jpg' ),
		),
		array(
			'slug' => 'uniform-tee-3pack', 'name' => 'Uniform Tee — 3 Pack', 'price' => 165, 'compareAt' => 285,
			'description' => 'Three Foundation tees — Ink, Bone, Vermilion — in one box. The rotation that ends decision fatigue.',
			'details' => array( '3 × 240gsm organic tees', 'Ink / Bone / Vermilion', 'Boxy square cut', 'Pre-shrunk' ),
			'category' => 'Essentials', 'sizes' => $apparel, 'colours' => $inkbone, 'rating' => 4.8, 'reviewCount' => 356, 'reviews' => array( 0, 1 ),
			'badge' => 'Value', 'stock' => 88, 'featured' => false,
			'images' => array( '1523381210434-271e8be1f52b.jpg', '1620799140408-edc6dcb6d633.jpg', '1618354691373-d851c5c3a990.jpg' ),
		),
		array(
			'slug' => 'column-slip-dress', 'name' => 'Column Slip Dress', 'price' => 265, 'compareAt' => 0,
			'description' => 'A bias-cut column in matte sandwashed silk that moves half a second behind you. Adjustable straps, zero hardware on show.',
			'details' => array( 'Sandwashed silk', 'Bias cut', 'Adjustable straps', 'Midi length' ),
			'category' => 'Tailoring', 'sizes' => $apparel, 'colours' => $inkbone, 'rating' => 4.9, 'reviewCount' => 174, 'reviews' => array( 2, 3, 5 ),
			'badge' => 'Limited', 'stock' => 11, 'featured' => true,
			'images' => array( '1594633312681-425c7b97ccd1.jpg', '1515372039744-b8f02a3ae446.jpg', '1496747611176-843222e1e57c.jpg' ),
		),
		array(
			'slug' => 'solar-field-shirt', 'name' => 'Solar Field Shirt', 'price' => 145, 'compareAt' => 0,
			'description' => 'A sun-faded overshirt in dry cotton twill with bellows pockets and matte snaps. Layers over everything, argues with nothing.',
			'details' => array( 'Dry cotton twill', 'Bellows chest pockets', 'Matte snap closures', 'Relaxed layering fit' ),
			'category' => 'Essentials', 'sizes' => $apparel,
			'colours' => array_merge( array( array( 'name' => 'Solar', 'hex' => '#D9A441' ) ), $inkbone ),
			'rating' => 4.6, 'reviewCount' => 97, 'reviews' => array( 4, 0 ),
			'badge' => '', 'stock' => 34, 'featured' => false,
			'images' => array( '1509631179647-0177331693ae.jpg', '1485968579580-b6d095142e6e.jpg', '1524504388940-b1c1722653e1.jpg' ),
		),
		array(
			'slug' => 'meridian-knit', 'name' => 'Meridian Knit', 'price' => 225, 'compareAt' => 260,
			'description' => 'A chunky half-cardigan stitch in undyed merino, knitted seamless so there is nothing to rub, pill or give up. Warmth without bulk.',
			'details' => array( '100% undyed merino', 'Seamless knit', 'Half-cardigan stitch', 'Naturally temperature regulating' ),
			'category' => 'Essentials', 'sizes' => $apparel,
			'colours' => array( array( 'name' => 'Bone', 'hex' => '#EDE8E0' ), array( 'name' => 'Ink', 'hex' => '#101010' ) ),
			'rating' => 4.8, 'reviewCount' => 143, 'reviews' => array( 1, 4 ),
			'badge' => '', 'stock' => 29, 'featured' => false,
			'images' => array( '1434389677669-e08b4cac3105.jpg', '1576566588028-4147f3842f27.jpg', '1621072156002-e2fccdc0b176.jpg' ),
		),
		array(
			'slug' => 'portrait-blazer', 'name' => 'Portrait Blazer', 'price' => 340, 'compareAt' => 0,
			'description' => 'Single-breasted, half-canvassed, with a roped shoulder and a ticket pocket. Tailoring that reads editorial, not corporate.',
			'details' => array( 'Half-canvassed construction', 'Roped shoulder', 'Horn buttons', 'Half-lined in vermilion' ),
			'category' => 'Tailoring', 'sizes' => $apparel, 'colours' => $inkbone, 'rating' => 4.9, 'reviewCount' => 76, 'reviews' => array( 3, 1 ),
			'badge' => 'Atelier', 'stock' => 8, 'featured' => true,
			'images' => array( '1552374196-c4e7ffc6e126.jpg', '1507680434567-5739c80be1ac.jpg', '1487412720507-e7ab37603c6f.jpg' ),
		),
		array(
			'slug' => 'gallery-slip-on', 'name' => 'Gallery Slip-On', 'price' => 175, 'compareAt' => 0,
			'description' => 'A laceless slip-on in brushed suede on a cushioned crepe sole. The shoe equivalent of a white gallery wall — quiet, perfect context.',
			'details' => array( 'Brushed suede upper', 'Natural crepe sole', 'Elastic gussets', 'Cork footbed' ),
			'category' => 'Footwear', 'sizes' => $shoes, 'colours' => $inkbone, 'rating' => 4.5, 'reviewCount' => 64, 'reviews' => array( 5, 4 ),
			'badge' => '', 'stock' => 47, 'featured' => false,
			'images' => array( '1600185365483-26d7a4cc7519.jpg', '1560769629-975ec94e6a86.jpg', '1549298916-b41d501d3772.jpg' ),
		),
	);
}

/**
 * Demo categories with their bento blurbs as descriptions.
 *
 * @return array<string,string>
 */
function vestige_demo_categories() {
	return array(
		'Outerwear' => 'Leather, wool, weather armour.',
		'Tailoring' => 'Blazers, denim, the column dress.',
		'Essentials' => 'Heavy tees and seamless knits.',
		'Footwear'  => 'Runners, courts, slip-ons.',
		'Objects'   => 'Packs and frames. Nothing extra.',
	);
}

/**
 * Register the admin page.
 */
function vestige_demo_admin_menu() {
	add_theme_page(
		esc_html__( 'Vestige Demo Import', 'vestige' ),
		esc_html__( 'Vestige Demo', 'vestige' ),
		'manage_options',
		'vestige-demo',
		'vestige_demo_page_render'
	);
}
add_action( 'admin_menu', 'vestige_demo_admin_menu' );

/**
 * Render the demo import page.
 */
function vestige_demo_page_render() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Vestige Demo Import', 'vestige' ); ?></h1>
		<?php if ( ! class_exists( 'WooCommerce' ) ) : ?>
			<div class="notice notice-warning"><p><?php esc_html_e( 'WooCommerce is not active. Install and activate the free WooCommerce plugin first — the demo store (products, cart, checkout) needs it.', 'vestige' ); ?></p></div>
		<?php endif; ?>
		<p><?php esc_html_e( 'This builds the demo store: 14 variable products with variations, prices, stock, galleries and reviews; the 5 categories; Size and Colour attributes; the 34 demo images in your media library; a drag-and-drop Home page assembled from the theme patterns; Shop / Cart / Checkout / My Account pages; menus; and WooCommerce settings (USD, free shipping over $200, $12 flat rate below).', 'vestige' ); ?></p>
		<p><?php esc_html_e( 'It is safe to run more than once — anything that already exists is skipped or repaired, never overwritten.', 'vestige' ); ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="vestige_import_demo" />
			<?php wp_nonce_field( 'vestige_import_demo', 'vestige_demo_nonce' ); ?>
			<?php submit_button( esc_html__( 'Import demo store', 'vestige' ), 'primary', 'submit', false ); ?>
		</form>
	</div>
	<?php
}

/**
 * Handle the import request.
 */
function vestige_handle_demo_import() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to run the demo import.', 'vestige' ) );
	}
	check_admin_referer( 'vestige_import_demo', 'vestige_demo_nonce' );

	$results = vestige_run_demo_import();

	set_transient( 'vestige_demo_result', $results, 60 );
	wp_safe_redirect( admin_url( 'themes.php?page=vestige-demo' ) );
	exit;
}
add_action( 'admin_post_vestige_import_demo', 'vestige_handle_demo_import' );

/**
 * Show the import result as an admin notice.
 */
function vestige_demo_result_notice() {
	$results = get_transient( 'vestige_demo_result' );
	if ( ! is_array( $results ) ) {
		return;
	}
	delete_transient( 'vestige_demo_result' );
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$created = isset( $results['created'] ) ? (int) $results['created'] : 0;
	$skipped = isset( $results['skipped'] ) ? (int) $results['skipped'] : 0;
	printf(
		'<div class="notice notice-success is-dismissible"><p>%s</p></div>',
		esc_html(
			sprintf(
				/* translators: 1: items created, 2: items skipped. */
				__( 'Vestige demo import finished: %1$d item(s) created, %2$d already existed and were skipped. Visit your homepage to see the store.', 'vestige' ),
				$created,
				$skipped
			)
		)
	);
}
add_action( 'admin_notices', 'vestige_demo_result_notice' );

/**
 * Copy a theme demo image into the uploads directory and create an
 * attachment. Returns the attachment ID, or 0 on any failure.
 * Re-running reuses the attachment matched by its demo slug.
 *
 * @param string $filename File inside assets/demo/.
 * @param int    $parent   Parent post ID.
 * @return int
 */
function vestige_sideload_demo_image( $filename, $parent = 0 ) {
	$source = get_template_directory() . '/assets/demo/' . $filename;
	if ( ! file_exists( $source ) ) {
		return 0;
	}

	$existing = get_posts(
		array(
			'post_type'      => 'attachment',
			'name'           => sanitize_title( pathinfo( $filename, PATHINFO_FILENAME ) . '-demo' ),
			'posts_per_page' => 1,
			'fields'         => 'ids',
		)
	);
	if ( $existing ) {
		return (int) $existing[0];
	}

	if ( ! function_exists( 'media_handle_sideload' ) || ! function_exists( 'wp_tempnam' ) ) {
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
	}

	$tmp = wp_tempnam( $filename );
	if ( ! $tmp ) {
		return 0;
	}
	// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_file_put_contents -- copying a bundled theme asset to a temp file for the media API.
	if ( false === file_put_contents( $tmp, file_get_contents( $source ) ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- bundled theme asset.
		wp_delete_file( $tmp );
		return 0;
	}

	$file_array = array(
		'name'     => $filename,
		'tmp_name' => $tmp,
	);
	$attachment_id = media_handle_sideload( $file_array, $parent, esc_html__( 'Vestige demo image', 'vestige' ) );
	if ( is_wp_error( $attachment_id ) ) {
		wp_delete_file( $tmp );
		return 0;
	}
	// Stable slug so re-runs find this attachment again.
	wp_update_post(
		array(
			'ID'        => (int) $attachment_id,
			'post_name' => sanitize_title( pathinfo( $filename, PATHINFO_FILENAME ) . '-demo' ),
		)
	);
	return (int) $attachment_id;
}

/**
 * Ensure a global attribute exists (Size / Colour). Returns the
 * taxonomy name ('pa_size' / 'pa_colour') or ''.
 *
 * @param string $label Attribute label.
 * @param string $slug  Attribute slug (without pa_).
 * @return string
 */
function vestige_ensure_attribute( $label, $slug ) {
	$taxonomy = 'pa_' . $slug;
	if ( function_exists( 'wc_create_attribute' ) ) {
		$exists = false;
		foreach ( wc_get_attribute_taxonomies() as $attr ) {
			if ( $attr->attribute_name === $slug ) {
				$exists = true;
				break;
			}
		}
		if ( ! $exists ) {
			wc_create_attribute(
				array(
					'name'         => $label,
					'slug'         => $slug,
					'type'         => 'select',
					'order_by'     => 'menu_order',
					'has_archives' => false,
				)
			);
			// Refresh the cached attribute list for this request.
			delete_transient( 'wc_attribute_taxonomies' );
			if ( class_exists( 'WC_Cache_Helper' ) ) {
				WC_Cache_Helper::invalidate_cache_group( 'woocommerce-attributes' );
			}
		}
	}
	if ( ! taxonomy_exists( $taxonomy ) ) {
		register_taxonomy(
			$taxonomy,
			array( 'product', 'product_variation' ),
			array(
				'label'        => $label,
				'hierarchical' => false,
				'public'       => false,
				'show_ui'      => false,
				'query_var'    => false,
				'rewrite'      => false,
			)
		);
	}
	return taxonomy_exists( $taxonomy ) ? $taxonomy : '';
}

/**
 * Ensure an attribute term exists; returns [term_id, slug].
 *
 * @param string $taxonomy Taxonomy.
 * @param string $name     Term name.
 * @return array{0:int,1:string}
 */
function vestige_ensure_term( $taxonomy, $name ) {
	$term = term_exists( $name, $taxonomy );
	if ( ! $term ) {
		$term = wp_insert_term( $name, $taxonomy );
	}
	if ( is_wp_error( $term ) || ! $term ) {
		return array( 0, sanitize_title( $name ) );
	}
	$term_id = is_array( $term ) ? (int) $term['term_id'] : (int) $term;
	$obj     = get_term( $term_id, $taxonomy );
	return array( $term_id, $obj ? $obj->slug : sanitize_title( $name ) );
}

/**
 * Create (or backfill) one demo product.
 *
 * @param array<string,mixed> $demo      Product data.
 * @param int                 $menu_order Loop order (featured first).
 * @param array<string,int>   $image_ids Sideloaded image IDs by filename.
 * @param int                 $cat_id    Category term ID.
 * @return string 'created' | 'skipped' | 'failed'
 */
function vestige_import_product( $demo, $menu_order, $image_ids, $cat_id ) {
	$existing = get_page_by_path( $demo['slug'], OBJECT, 'product' );

	if ( $existing ) {
		// Backfill anything an earlier, partial import missed.
		$pid = (int) $existing->ID;
		if ( ! has_post_thumbnail( $pid ) && ! empty( $image_ids[ $demo['images'][0] ] ) ) {
			set_post_thumbnail( $pid, $image_ids[ $demo['images'][0] ] );
		}
		if ( ! get_post_meta( $pid, '_vestige_badge', true ) && '' !== $demo['badge'] ) {
			update_post_meta( $pid, '_vestige_badge', $demo['badge'] );
		}
		if ( ! get_post_meta( $pid, '_vestige_details', true ) ) {
			update_post_meta( $pid, '_vestige_details', implode( "\n", $demo['details'] ) );
		}
		return 'skipped';
	}

	if ( ! class_exists( 'WC_Product_Variable' ) ) {
		return 'failed';
	}

	$size_tax   = 'pa_size';
	$colour_tax = 'pa_colour';

	$size_terms   = array();
	$colour_terms = array();
	foreach ( $demo['sizes'] as $size ) {
		list( $tid, $tslug ) = vestige_ensure_term( $size_tax, $size );
		if ( $tid ) {
			$size_terms[] = array( 'id' => $tid, 'slug' => $tslug, 'name' => $size );
		}
	}
	foreach ( $demo['colours'] as $colour ) {
		list( $tid, $tslug ) = vestige_ensure_term( $colour_tax, $colour['name'] );
		if ( $tid ) {
			update_term_meta( $tid, 'vestige_hex', $colour['hex'] );
			$colour_terms[] = array( 'id' => $tid, 'slug' => $tslug, 'name' => $colour['name'] );
		}
	}
	if ( ! $size_terms || ! $colour_terms ) {
		return 'failed';
	}

	$product = new WC_Product_Variable();
	$product->set_name( $demo['name'] );
	$product->set_slug( $demo['slug'] );
	$product->set_status( 'publish' );
	$product->set_catalog_visibility( 'visible' );
	$product->set_description( $demo['description'] );
	$product->set_menu_order( $menu_order );
	$product->set_featured( ! empty( $demo['featured'] ) );
	$product->set_reviews_allowed( true );
	if ( $cat_id ) {
		$product->set_category_ids( array( $cat_id ) );
	}

	$mk_attr = function ( $taxonomy, $terms ) {
		$attr = new WC_Product_Attribute();
		$attr->set_id( wc_attribute_taxonomy_id_by_name( $taxonomy ) );
		$attr->set_name( $taxonomy );
		$attr->set_options( wp_list_pluck( $terms, 'id' ) );
		$attr->set_visible( true );
		$attr->set_variation( true );
		return $attr;
	};
	$product->set_attributes( array( $mk_attr( $size_tax, $size_terms ), $mk_attr( $colour_tax, $colour_terms ) ) );

	$product_id = $product->save();
	if ( ! $product_id ) {
		return 'failed';
	}

	// Images: first is the cover, the rest the gallery.
	$img_ids = array();
	foreach ( $demo['images'] as $file ) {
		if ( ! empty( $image_ids[ $file ] ) ) {
			$img_ids[] = (int) $image_ids[ $file ];
		}
	}
	if ( $img_ids ) {
		set_post_thumbnail( $product_id, $img_ids[0] );
		if ( count( $img_ids ) > 1 ) {
			update_post_meta( $product_id, '_product_image_gallery', implode( ',', array_slice( $img_ids, 1 ) ) );
		}
	}

	// Variations: one per size × colour, all at the product's price/stock.
	$regular = ! empty( $demo['compareAt'] ) ? (float) $demo['compareAt'] : (float) $demo['price'];
	$sale    = ! empty( $demo['compareAt'] ) ? (float) $demo['price'] : null;
	foreach ( $size_terms as $size ) {
		foreach ( $colour_terms as $colour ) {
			$variation = new WC_Product_Variation();
			$variation->set_parent_id( $product_id );
			$variation->set_attributes(
				array(
					'attribute_pa_size'   => $size['slug'],
					'attribute_pa_colour' => $colour['slug'],
				)
			);
			$variation->set_regular_price( (string) $regular );
			if ( null !== $sale ) {
				$variation->set_sale_price( (string) $sale );
			}
			$variation->set_manage_stock( true );
			$variation->set_stock_quantity( (int) $demo['stock'] );
			$variation->set_stock_status( 'instock' );
			$variation->set_status( 'publish' );
			$variation->save();
		}
	}
	// Sync parent price/stock ranges after variations exist.
	if ( class_exists( 'WC_Product_Variable' ) ) {
		WC_Product_Variable::sync( $product_id );
	}

	// Vestige meta + the source catalogue's rating numbers.
	update_post_meta( $product_id, '_vestige_badge', $demo['badge'] );
	update_post_meta( $product_id, '_vestige_details', implode( "\n", $demo['details'] ) );
	update_post_meta( $product_id, '_vestige_review_count', (int) $demo['reviewCount'] );
	update_post_meta( $product_id, '_wc_average_rating', (float) $demo['rating'] );
	$five = (int) round( $demo['reviewCount'] * 0.82 );
	update_post_meta(
		$product_id,
		'_wc_rating_count',
		array(
			5 => $five,
			4 => max( 0, (int) $demo['reviewCount'] - $five ),
		)
	);

	// Reviews (approved, rated, verified) — matched by author + product.
	$pool = vestige_demo_review_pool();
	foreach ( $demo['reviews'] as $idx ) {
		if ( ! isset( $pool[ $idx ] ) ) {
			continue;
		}
		$review   = $pool[ $idx ];
		$existing_reviews = get_comments(
			array(
				'post_id' => $product_id,
				'author_email' => sanitize_title( $review['author'] ) . '@example.com',
				'type'    => 'review',
				'number'  => 1,
				'fields'  => 'ids',
			)
		);
		if ( $existing_reviews ) {
			continue;
		}
		$comment_id = wp_insert_comment(
			array(
				'comment_post_ID'      => $product_id,
				'comment_author'       => $review['author'],
				'comment_author_email' => sanitize_title( $review['author'] ) . '@example.com',
				'comment_content'      => $review['title'] . "\n\n" . $review['body'],
				'comment_approved'     => 1,
				'comment_type'         => 'review',
				'comment_date'         => $review['date'] . ' 12:00:00',
				'user_id'              => 0,
			)
		);
		if ( $comment_id ) {
			add_comment_meta( $comment_id, 'rating', (int) $review['rating'], true );
			add_comment_meta( $comment_id, 'verified', 1, true );
		}
	}
	// Restore the source average after Woo's comment hooks recount.
	update_post_meta( $product_id, '_wc_average_rating', (float) $demo['rating'] );

	return 'created';
}

/**
 * Create a page if missing. Returns [page_id, created_bool].
 *
 * @param string $slug    Page slug.
 * @param string $title   Page title.
 * @param string $content Page content.
 * @return array{0:int,1:bool}
 */
function vestige_ensure_page( $slug, $title, $content ) {
	$existing = get_page_by_path( $slug, OBJECT, 'page' );
	if ( $existing ) {
		return array( (int) $existing->ID, false );
	}
	$page_id = wp_insert_post(
		array(
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_title'   => $title,
			'post_name'    => $slug,
			'post_content' => $content,
		),
		true
	);
	if ( is_wp_error( $page_id ) || ! $page_id ) {
		return array( 0, false );
	}
	return array( (int) $page_id, true );
}

/**
 * WooCommerce settings + the demo shipping zone (free ≥ $200, else $12).
 */
function vestige_import_woo_settings() {
	update_option( 'woocommerce_currency', 'USD' );
	update_option( 'woocommerce_currency_pos', 'left' );
	// Fresh WooCommerce installs (9.1+) hide the whole store behind
	// "Coming soon" until launch — a demo store must be visible, or
	// buyers who run this import see no shop at all.
	update_option( 'woocommerce_coming_soon', 'no' );
	update_option( 'woocommerce_enable_reviews', 'yes' );
	update_option( 'woocommerce_review_rating_required', 'yes' );

	if ( ! class_exists( 'WC_Shipping_Zone' ) ) {
		return;
	}
	$zone_id = 0;
	foreach ( WC_Shipping_Zones::get_zones() as $zone ) {
		if ( isset( $zone['zone_name'] ) && 'Vestige Everywhere' === $zone['zone_name'] ) {
			$zone_id = (int) $zone['id'];
			break;
		}
	}
	if ( ! $zone_id ) {
		$zone = new WC_Shipping_Zone();
		$zone->set_zone_name( 'Vestige Everywhere' );
		$zone->save();
		$zone_id = $zone->get_id();
	}
	if ( ! $zone_id ) {
		return;
	}
	$zone    = WC_Shipping_Zones::get_zone( $zone_id );
	$methods = wp_list_pluck( $zone->get_shipping_methods(), 'id' );

	if ( ! in_array( 'free_shipping', $methods, true ) ) {
		$instance = $zone->add_shipping_method( 'free_shipping' );
		if ( $instance ) {
			update_option(
				'woocommerce_free_shipping_' . $instance . '_settings',
				array(
					'title'            => 'Free shipping',
					'requires'         => 'min_amount',
					'min_amount'       => (string) vestige_free_shipping_threshold(),
					'ignore_discounts' => 'no',
				)
			);
		}
	}
	if ( ! in_array( 'flat_rate', $methods, true ) ) {
		$instance = $zone->add_shipping_method( 'flat_rate' );
		if ( $instance ) {
			update_option(
				'woocommerce_flat_rate_' . $instance . '_settings',
				array(
					'title'      => 'Flat rate',
					'cost'       => '12',
					'tax_status' => 'none',
					'class_costs' => array(),
					'no_class_cost' => '',
					'type'       => 'class',
				)
			);
		}
	}
}

/**
 * Run the import. Returns counts of created / skipped items.
 *
 * @return array{created:int,skipped:int}
 */
function vestige_run_demo_import() {
	$created = 0;
	$skipped = 0;
	$tally   = function ( $result ) use ( &$created, &$skipped ) {
		if ( 'created' === $result ) {
			$created++;
		} else {
			$skipped++;
		}
	};

	if ( ! class_exists( 'WooCommerce' ) ) {
		return array( 'created' => 0, 'skipped' => 0 );
	}

	/* --- Attributes ------------------------------------------------------ */
	vestige_ensure_attribute( 'Size', 'size' );
	vestige_ensure_attribute( 'Colour', 'colour' );

	/* --- Images ------------------------------------------------------------ */
	$image_ids = array();
	$files     = array();
	foreach ( vestige_demo_products() as $demo ) {
		foreach ( $demo['images'] as $file ) {
			$files[ $file ] = true;
		}
	}
	$files['1490481651871-ab68de25d43d.jpg'] = true; // Hero image.
	foreach ( array_keys( $files ) as $file ) {
		$id = vestige_sideload_demo_image( $file );
		if ( $id ) {
			$image_ids[ $file ] = $id;
		}
	}

	/* --- Categories ---------------------------------------------------------- */
	$cat_ids = array();
	foreach ( vestige_demo_categories() as $name => $blurb ) {
		$term = term_exists( $name, 'product_cat' );
		if ( ! $term ) {
			$term = wp_insert_term( $name, 'product_cat', array( 'description' => $blurb ) );
			if ( ! is_wp_error( $term ) ) {
				$created++;
			}
		} else {
			$skipped++;
		}
		if ( $term && ! is_wp_error( $term ) ) {
			$cat_ids[ $name ] = is_array( $term ) ? (int) $term['term_id'] : (int) $term;
		}
	}

	/* --- Products (featured first, for the loop order) ------------------------- */
	$products = vestige_demo_products();
	usort(
		$products,
		function ( $a, $b ) {
			return ( ! empty( $b['featured'] ) ? 1 : 0 ) <=> ( ! empty( $a['featured'] ) ? 1 : 0 );
		}
	);
	foreach ( $products as $i => $demo ) {
		$tally( vestige_import_product( $demo, $i + 1, $image_ids, isset( $cat_ids[ $demo['category'] ] ) ? $cat_ids[ $demo['category'] ] : 0 ) );
	}

	/* --- Pages ------------------------------------------------------------------ */
	$img_url = function ( $file ) use ( $image_ids ) {
		return ! empty( $image_ids[ $file ] ) ? (string) wp_get_attachment_url( $image_ids[ $file ] ) : '';
	};
	$home_images = array(
		'hero'   => $img_url( '1490481651871-ab68de25d43d.jpg' ),
		'story1' => $img_url( '1521572163474-6864f9cf17ab.jpg' ),
		'story2' => $img_url( '1551028719-00167b16eac5.jpg' ),
		'story3' => $img_url( '1594633312681-425c7b97ccd1.jpg' ),
		'story4' => $img_url( '1434389677669-e08b4cac3105.jpg' ),
		'note1'  => $img_url( '1551028719-00167b16eac5.jpg' ),
		'note2'  => $img_url( '1539109136881-3be0616acf4b.jpg' ),
		'note3'  => $img_url( '1594633312681-425c7b97ccd1.jpg' ),
	);

	list( $home_id, $home_created ) = vestige_ensure_page( 'home', __( 'Home', 'vestige' ), vestige_home_content( $home_images ) );
	$tally( $home_created ? 'created' : 'skipped' );
	// Backfill: an existing but empty Home page gets the pattern content.
	if ( $home_id && ! $home_created ) {
		$home_post = get_post( $home_id );
		if ( $home_post && '' === trim( (string) $home_post->post_content ) ) {
			wp_update_post( array( 'ID' => $home_id, 'post_content' => vestige_home_content( $home_images ) ) );
		}
	}

	list( $shop_id, $c ) = vestige_ensure_page( 'shop', __( 'Shop', 'vestige' ), '' );
	$tally( $c ? 'created' : 'skipped' );
	list( $cart_id, $c ) = vestige_ensure_page( 'cart', __( 'Cart', 'vestige' ), '<!-- wp:shortcode -->[woocommerce_cart]<!-- /wp:shortcode -->' );
	$tally( $c ? 'created' : 'skipped' );
	list( $checkout_id, $c ) = vestige_ensure_page( 'checkout', __( 'Checkout', 'vestige' ), '<!-- wp:shortcode -->[woocommerce_checkout]<!-- /wp:shortcode -->' );
	$tally( $c ? 'created' : 'skipped' );
	list( $account_id, $c ) = vestige_ensure_page( 'my-account', __( 'My Account', 'vestige' ), '<!-- wp:shortcode -->[woocommerce_my_account]<!-- /wp:shortcode -->' );
	$tally( $c ? 'created' : 'skipped' );

	if ( $shop_id ) {
		update_option( 'woocommerce_shop_page_id', $shop_id );
	}
	if ( $cart_id ) {
		update_option( 'woocommerce_cart_page_id', $cart_id );
	}
	if ( $checkout_id ) {
		update_option( 'woocommerce_checkout_page_id', $checkout_id );
	}
	if ( $account_id ) {
		update_option( 'woocommerce_myaccount_page_id', $account_id );
	}
	if ( $home_id && 'page' !== get_option( 'show_on_front' ) ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $home_id );
	}

	/* --- Menus --------------------------------------------------------------------- */
	$locations = get_theme_mod( 'nav_menu_locations', array() );
	if ( empty( $locations['primary'] ) ) {
		$menu_id = wp_create_nav_menu( 'Primary' );
		if ( ! is_wp_error( $menu_id ) && $menu_id ) {
			wp_update_nav_menu_item( $menu_id, 0, array( 'menu-item-title' => __( 'Home', 'vestige' ), 'menu-item-url' => home_url( '/' ), 'menu-item-status' => 'publish' ) );
			if ( $shop_id ) {
				wp_update_nav_menu_item( $menu_id, 0, array( 'menu-item-title' => __( 'Shop', 'vestige' ), 'menu-item-object-id' => $shop_id, 'menu-item-object' => 'page', 'menu-item-type' => 'post_type', 'menu-item-status' => 'publish' ) );
			}
			if ( $checkout_id ) {
				wp_update_nav_menu_item( $menu_id, 0, array( 'menu-item-title' => __( 'Checkout', 'vestige' ), 'menu-item-object-id' => $checkout_id, 'menu-item-object' => 'page', 'menu-item-type' => 'post_type', 'menu-item-status' => 'publish' ) );
			}
			$locations['primary'] = $menu_id;
			$created++;
		}
	} else {
		$skipped++;
	}
	if ( empty( $locations['footer'] ) ) {
		$menu_id = wp_create_nav_menu( 'Footer' );
		if ( ! is_wp_error( $menu_id ) && $menu_id ) {
			if ( $shop_id ) {
				wp_update_nav_menu_item( $menu_id, 0, array( 'menu-item-title' => __( 'Shop', 'vestige' ), 'menu-item-object-id' => $shop_id, 'menu-item-object' => 'page', 'menu-item-type' => 'post_type', 'menu-item-status' => 'publish' ) );
			}
			if ( $checkout_id ) {
				wp_update_nav_menu_item( $menu_id, 0, array( 'menu-item-title' => __( 'Checkout', 'vestige' ), 'menu-item-object-id' => $checkout_id, 'menu-item-object' => 'page', 'menu-item-type' => 'post_type', 'menu-item-status' => 'publish' ) );
			}
			$locations['footer'] = $menu_id;
			$created++;
		}
	} else {
		$skipped++;
	}
	set_theme_mod( 'nav_menu_locations', $locations );

	/* --- Site identity (only while it is still the WP default) ---------------------- */
	if ( in_array( get_option( 'blogname' ), array( 'My Site', 'My WordPress Site', 'My WordPress Website', '' ), true ) ) {
		update_option( 'blogname', 'VESTIGE' );
		update_option( 'blogdescription', 'Wear What Remains' );
	}

	/* --- Woo settings + shipping -------------------------------------------------------- */
	vestige_import_woo_settings();

	flush_rewrite_rules();
	return array(
		'created' => $created,
		'skipped' => $skipped,
	);
}
