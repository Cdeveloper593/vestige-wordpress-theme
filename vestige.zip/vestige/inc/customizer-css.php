<?php
/**
 * Output Customizer colours as CSS variables.
 *
 * @package Vestige
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Convert a hex colour to an [r, g, b] array.
 *
 * @param string $hex Hex colour, with or without '#'.
 * @return array<int,int>|null
 */
function vestige_hex_to_rgb( $hex ) {
	$hex = ltrim( (string) $hex, '#' );
	if ( 3 === strlen( $hex ) ) {
		$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
	}
	if ( 6 !== strlen( $hex ) || ! ctype_xdigit( $hex ) ) {
		return null;
	}
	return array(
		hexdec( substr( $hex, 0, 2 ) ),
		hexdec( substr( $hex, 2, 2 ) ),
		hexdec( substr( $hex, 4, 2 ) ),
	);
}

/**
 * Print the :root overrides for Customizer colours in the head.
 * Runs late (priority 20) so it wins over the enqueued stylesheets.
 * Also feeds the block editor palette via theme.json-free CSS vars —
 * patterns reference var(--ink) etc. through block color slugs mapped
 * in inc/patterns.php inline styles.
 */
function vestige_customizer_css() {
	$ink    = sanitize_hex_color( (string) vestige_mod( 'vestige_color_ink', '#101010' ) );
	$bone   = sanitize_hex_color( (string) vestige_mod( 'vestige_color_bone', '#EDE8E0' ) );
	$accent = sanitize_hex_color( (string) vestige_mod( 'vestige_color_accent', '#FF4D00' ) );

	if ( ! $ink && ! $bone && ! $accent ) {
		return;
	}

	echo "<style id=\"vestige-customizer-css\">\n:root {\n";
	if ( $ink ) {
		echo '--ink: ' . esc_html( $ink ) . ";\n";
	}
	if ( $bone ) {
		echo '--bone: ' . esc_html( $bone ) . ";\n";
	}
	if ( $accent ) {
		echo '--accent: ' . esc_html( $accent ) . ";\n";
	}
	echo "}\n</style>\n";
}
add_action( 'wp_head', 'vestige_customizer_css', 20 );
