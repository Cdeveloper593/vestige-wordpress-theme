<?php
/**
 * Main template: blog index / fallback for everything.
 *
 * @package Vestige
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="content" class="site-main">
	<div class="wrap content-wrap">
		<?php if ( have_posts() ) : ?>
			<header class="page-header" style="margin-bottom:2.5rem">
				<p class="eyebrow"><?php esc_html_e( 'The Journal', 'vestige' ); ?></p>
				<h1 class="entry-title"><?php echo is_home() ? esc_html__( 'Latest posts', 'vestige' ) : esc_html( get_the_archive_title() ); ?></h1>
			</header>
			<div class="blog-grid">
				<?php
				while ( have_posts() ) :
					the_post();
					?>
					<article id="post-<?php the_ID(); ?>" <?php post_class( 'post-card' ); ?>>
						<?php if ( has_post_thumbnail() ) : ?>
							<div class="ph">
								<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'vestige-wide' ); ?></a>
							</div>
						<?php endif; ?>
						<p class="entry-meta"><?php vestige_posted_on(); ?></p>
						<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
						<div class="entry-summary"><?php the_excerpt(); ?></div>
						<a class="btn-ghost" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Read more', 'vestige' ); ?></a>
					</article>
					<?php
				endwhile;
				?>
			</div>
			<?php the_posts_pagination(); ?>
		<?php else : ?>
			<h1 class="entry-title"><?php esc_html_e( 'Nothing remains', 'vestige' ); ?></h1>
			<p class="lede"><?php esc_html_e( 'No posts yet. Check back after the next drop.', 'vestige' ); ?></p>
		<?php endif; ?>
	</div>
</main>

<?php
get_footer();
