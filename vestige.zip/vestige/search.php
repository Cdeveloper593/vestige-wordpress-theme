<?php
/**
 * Search results.
 *
 * @package Vestige
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="content" class="site-main">
	<div class="wrap content-wrap">
		<header class="page-header" style="margin-bottom:2.5rem">
			<p class="eyebrow"><?php esc_html_e( 'Search', 'vestige' ); ?></p>
			<h1 class="entry-title">
				<?php
				printf(
					/* translators: %s: search query. */
					esc_html__( 'Results for “%s”', 'vestige' ),
					esc_html( get_search_query() )
				);
				?>
			</h1>
			<?php get_search_form(); ?>
		</header>
		<?php if ( have_posts() ) : ?>
			<div class="blog-grid">
				<?php
				while ( have_posts() ) :
					the_post();
					?>
					<article id="post-<?php the_ID(); ?>" <?php post_class( 'post-card' ); ?>>
						<?php if ( has_post_thumbnail() ) : ?>
							<div class="ph">
								<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'vestige-wide' ); ?></a>
							</div>
						<?php endif; ?>
						<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
						<div class="entry-summary"><?php the_excerpt(); ?></div>
					</article>
					<?php
				endwhile;
				?>
			</div>
			<?php the_posts_pagination(); ?>
		<?php else : ?>
			<p class="lede"><?php esc_html_e( 'Nothing remains matching that search. Loosen the terms and try again.', 'vestige' ); ?></p>
		<?php endif; ?>
	</div>
</main>

<?php
get_footer();
