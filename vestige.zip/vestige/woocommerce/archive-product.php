<?php
/**
 * Shop / product-category archive.
 *
 * Layout mirrors the source template's Shop page: a gradient hero
 * band, then a sticky sidebar (search, category buttons, max price,
 * sort) beside the product grid. All filters are plain GET forms on
 * the native WooCommerce query — no filter plugin needed:
 *   - search      → 's' + post_type=product (core search)
 *   - category    → product_cat term archives
 *   - max price   → 'max_price', applied in inc/woocommerce.php
 *   - sort        → Woo's native 'orderby' (featured / price / name / rating)
 *
 * @package Vestige
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$vestige_shop_url  = vestige_shop_url();
$vestige_is_search = isset( $_GET['s'] ) && '' !== trim( sanitize_text_field( wp_unslash( $_GET['s'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$vestige_max_price = isset( $_GET['max_price'] ) ? abs( (float) wp_unslash( $_GET['max_price'] ) ) : 500; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$vestige_orderby   = isset( $_GET['orderby'] ) ? sanitize_text_field( wp_unslash( $_GET['orderby'] ) ) : 'menu_order'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$vestige_current_cat = is_tax( 'product_cat' ) ? get_queried_object() : null;
?>

<main id="content" class="site-main">
	<div class="wrap shop-wrap">

		<section class="shop-hero vestige-aurora">
			<?php vestige_breadcrumbs(); ?>
			<p class="eyebrow">
				<?php
				printf(
					/* translators: %s: drop label from the Customizer. */
					esc_html__( 'Drop 04 — %s pieces', 'vestige' ),
					esc_html( (string) wp_count_posts( 'product' )->publish )
				);
				?>
			</p>
			<h1 class="shop-title">
				<?php
				if ( $vestige_current_cat ) {
					echo esc_html( $vestige_current_cat->name );
				} elseif ( $vestige_is_search ) {
					esc_html_e( 'Search the drop', 'vestige' );
				} else {
					esc_html_e( 'Shop All Remains', 'vestige' );
				}
				?>
			</h1>
			<p class="lede"><?php esc_html_e( 'Search, filter by category and price, sort how you like. Name and price stay readable — always.', 'vestige' ); ?></p>
		</section>

		<div class="shop-layout">
			<aside class="shop-sidebar" aria-label="<?php esc_attr_e( 'Product filters', 'vestige' ); ?>">
				<form class="shop-filter" method="get" action="<?php echo esc_url( $vestige_shop_url ); ?>" role="search">
					<label class="eyebrow" for="vestige-shop-search"><?php esc_html_e( 'Search', 'vestige' ); ?></label>
					<input id="vestige-shop-search" type="search" name="s" placeholder="<?php esc_attr_e( 'Leather, tee, runner…', 'vestige' ); ?>"
						value="<?php echo esc_attr( $vestige_is_search ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '' ); ?>" />
					<input type="hidden" name="post_type" value="product" />
				</form>

				<div class="shop-filter">
					<p class="eyebrow" id="vestige-cat-label"><?php esc_html_e( 'Category', 'vestige' ); ?></p>
					<div class="cat-buttons" role="group" aria-labelledby="vestige-cat-label">
						<a class="cat-btn<?php echo $vestige_current_cat ? '' : ' is-active'; ?>" href="<?php echo esc_url( $vestige_shop_url ); ?>"><?php esc_html_e( 'All', 'vestige' ); ?></a>
						<?php
						$vestige_cats = get_terms(
							array(
								'taxonomy'   => 'product_cat',
								'hide_empty' => false,
								'exclude'    => array( (int) get_option( 'default_product_cat', 0 ) ),
							)
						);
						if ( $vestige_cats && ! is_wp_error( $vestige_cats ) ) {
							foreach ( $vestige_cats as $vestige_cat ) {
								$vestige_link = get_term_link( $vestige_cat );
								if ( is_wp_error( $vestige_link ) ) {
									continue;
								}
								$vestige_active = $vestige_current_cat && (int) $vestige_current_cat->term_id === (int) $vestige_cat->term_id;
								echo '<a class="cat-btn' . ( $vestige_active ? ' is-active' : '' ) . '" href="' . esc_url( $vestige_link ) . '">' . esc_html( $vestige_cat->name ) . '</a>';
							}
						}
						?>
					</div>
				</div>

				<form class="shop-filter" method="get" action="<?php echo esc_url( $vestige_current_cat ? get_term_link( $vestige_current_cat ) : $vestige_shop_url ); ?>">
					<?php if ( $vestige_is_search ) : ?>
						<input type="hidden" name="s" value="<?php echo esc_attr( sanitize_text_field( wp_unslash( $_GET['s'] ) ) ); ?>" />
						<input type="hidden" name="post_type" value="product" />
					<?php endif; ?>
					<?php if ( 'menu_order' !== $vestige_orderby ) : ?>
						<input type="hidden" name="orderby" value="<?php echo esc_attr( $vestige_orderby ); ?>" />
					<?php endif; ?>
					<label class="eyebrow" for="vestige-max-price">
						<?php
						printf(
							/* translators: %s: formatted max price. */
							esc_html__( 'Max price — %s', 'vestige' ),
							esc_html( '$' . number_format_i18n( $vestige_max_price ) )
						);
						?>
					</label>
					<input id="vestige-max-price" type="range" min="25" max="500" step="25" name="max_price" value="<?php echo esc_attr( (string) $vestige_max_price ); ?>" />
					<label class="price-number-label">
						<?php esc_html_e( 'Max price in dollars', 'vestige' ); ?>
						<input type="number" min="0" max="500" step="25" name="max_price" value="<?php echo esc_attr( (string) $vestige_max_price ); ?>" />
					</label>
					<button type="submit" class="btn-ghost filter-apply"><?php esc_html_e( 'Apply price', 'vestige' ); ?></button>
				</form>

				<form class="shop-filter" method="get" action="<?php echo esc_url( $vestige_current_cat ? get_term_link( $vestige_current_cat ) : $vestige_shop_url ); ?>">
					<?php if ( $vestige_is_search ) : ?>
						<input type="hidden" name="s" value="<?php echo esc_attr( sanitize_text_field( wp_unslash( $_GET['s'] ) ) ); ?>" />
						<input type="hidden" name="post_type" value="product" />
					<?php endif; ?>
					<?php if ( $vestige_max_price < 500 ) : ?>
						<input type="hidden" name="max_price" value="<?php echo esc_attr( (string) $vestige_max_price ); ?>" />
					<?php endif; ?>
					<label class="eyebrow" for="vestige-sort"><?php esc_html_e( 'Sort', 'vestige' ); ?></label>
					<select id="vestige-sort" name="orderby" onchange="this.form.submit()">
						<option value="menu_order"<?php selected( $vestige_orderby, 'menu_order' ); ?>><?php esc_html_e( 'Featured', 'vestige' ); ?></option>
						<option value="price"<?php selected( $vestige_orderby, 'price' ); ?>><?php esc_html_e( 'Price — low to high', 'vestige' ); ?></option>
						<option value="price-desc"<?php selected( $vestige_orderby, 'price-desc' ); ?>><?php esc_html_e( 'Price — high to low', 'vestige' ); ?></option>
						<option value="title"<?php selected( $vestige_orderby, 'title' ); ?>><?php esc_html_e( 'Name A–Z', 'vestige' ); ?></option>
						<option value="rating"<?php selected( $vestige_orderby, 'rating' ); ?>><?php esc_html_e( 'Top rated', 'vestige' ); ?></option>
					</select>
				</form>
			</aside>

			<section class="shop-results" aria-live="polite">
				<?php if ( woocommerce_product_loop() ) : ?>
					<p class="result-count" role="status">
						<?php
						$vestige_total = (int) $GLOBALS['wp_query']->found_posts;
						printf(
							/* translators: %d: number of products. */
							esc_html( _n( '%d piece', '%d pieces', $vestige_total, 'vestige' ) ),
							$vestige_total
						);
						if ( $vestige_current_cat ) {
							printf( ' %s', esc_html( sprintf( /* translators: %s: category name. */ __( 'in %s', 'vestige' ), $vestige_current_cat->name ) ) );
						}
						?>
					</p>
					<?php
					woocommerce_product_loop_start();
					while ( have_posts() ) {
						the_post();
						do_action( 'woocommerce_shop_loop' );
						wc_get_template_part( 'content', 'product' );
					}
					woocommerce_product_loop_end();
					the_posts_pagination(
						array(
							'mid_size'  => 1,
							'prev_text' => __( '← Prev', 'vestige' ),
							'next_text' => __( 'Next →', 'vestige' ),
						)
					);
					?>
				<?php else : ?>
					<div class="nothing-remains">
						<h2 class="display"><?php esc_html_e( 'Nothing remains', 'vestige' ); ?></h2>
						<p class="text-sand"><?php esc_html_e( 'No pieces match that combination. Loosen a filter.', 'vestige' ); ?></p>
						<a class="btn-ghost" href="<?php echo esc_url( $vestige_shop_url ); ?>"><?php esc_html_e( 'Reset all filters', 'vestige' ); ?></a>
					</div>
				<?php endif; ?>
			</section>
		</div>
	</div>
</main>

<?php
get_footer();
