<?php
/**
 * Customizer: brand, colours, and the default copy used by the
 * homepage block patterns. Every setting has an explicit sanitize
 * callback. Note the division of labour, documented for buyers:
 * page sections are edited drag-and-drop in the block editor (they
 * are block patterns); the Customizer holds the global brand —
 * colours, announcement, footer — plus the *default* copy the
 * patterns are seeded with by the demo import.
 *
 * Textarea formats (documented in the buyer guide):
 *   Category tiles: Name | Label | Blurb          (one per line)
 *   Editorial notes: Eyebrow | Title | Text       (one per line)
 *   Socials:         Label | URL                  (one per line)
 *   Press names / method cards: one per line.
 *
 * @package Vestige
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sanitize a plain-text Customizer value.
 *
 * @param string $value Raw value.
 * @return string
 */
function vestige_sanitize_text( $value ) {
	return sanitize_text_field( is_string( $value ) ? $value : '' );
}

/**
 * Sanitize a textarea value, keeping line breaks.
 *
 * @param string $value Raw value.
 * @return string
 */
function vestige_sanitize_textarea( $value ) {
	return sanitize_textarea_field( is_string( $value ) ? $value : '' );
}

/**
 * Sanitize "a | b | c" line lists (tiles / notes / socials): keep the
 * pipe format, strip anything that is not a plain line.
 *
 * @param string $value Raw value.
 * @return string
 */
function vestige_sanitize_lines( $value ) {
	$clean = array();
	foreach ( vestige_lines( sanitize_textarea_field( is_string( $value ) ? $value : '' ) ) as $line ) {
		$clean[] = implode( ' | ', array_map( 'trim', explode( '|', $line ) ) );
	}
	return implode( "\n", $clean );
}

/**
 * Register all Vestige Customizer panels, sections, settings, controls.
 *
 * @param WP_Customize_Manager $wp_customize Customizer manager.
 */
function vestige_customize_register( $wp_customize ) {

	/* --- Panel ---------------------------------------------------------- */
	$wp_customize->add_panel(
		'vestige_panel',
		array(
			'title'       => esc_html__( 'Vestige', 'vestige' ),
			'description' => esc_html__( 'Brand, colours and default homepage copy for the Vestige WooCommerce theme. Homepage sections themselves are edited drag-and-drop in the block editor (Pages → Home).', 'vestige' ),
			'priority'    => 30,
		)
	);

	$add = function ( $section, $section_args, $fields ) use ( $wp_customize ) {
		$wp_customize->add_section( $section, array_merge( array( 'panel' => 'vestige_panel' ), $section_args ) );
		foreach ( $fields as $id => $field ) {
			$wp_customize->add_setting(
				$id,
				array(
					'default'           => isset( $field['default'] ) ? $field['default'] : '',
					'sanitize_callback' => isset( $field['sanitize'] ) ? $field['sanitize'] : 'vestige_sanitize_text',
					'transport'         => isset( $field['transport'] ) ? $field['transport'] : 'refresh',
				)
			);
			$control_args = array(
				'label'   => $field['label'],
				'section' => $section,
			);
			if ( isset( $field['description'] ) ) {
				$control_args['description'] = $field['description'];
			}
			$type = isset( $field['type'] ) ? $field['type'] : 'text';
			if ( 'color' === $type ) {
				$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $id, $control_args ) );
			} elseif ( 'image' === $type ) {
				$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, $id, $control_args ) );
			} else {
				$control_args['type'] = $type;
				$wp_customize->add_control( $id, $control_args );
			}
		}
	};

	/* --- Brand & announcement -------------------------------------------- */
	$add(
		'vestige_brand',
		array(
			'title'    => esc_html__( 'Brand & Announcement', 'vestige' ),
			'priority' => 10,
		),
		array(
			'vestige_announcement'     => array(
				'label'   => esc_html__( 'Announcement bar text', 'vestige' ),
				'default' => 'Free shipping over $200 — Drop 04 live now',
			),
			'vestige_footer_note'      => array(
				'label'   => esc_html__( 'Footer note (right side of the footer bar)', 'vestige' ),
				'default' => '© ' . gmdate( 'Y' ) . ' Vestige. Wear what remains.',
			),
			'vestige_footer_tagline'   => array(
				'label'   => esc_html__( 'Footer tagline next to the wordmark', 'vestige' ),
				'default' => '— wear what remains',
			),
			'vestige_socials'          => array(
				'label'       => esc_html__( 'Social links', 'vestige' ),
				'type'        => 'textarea',
				'sanitize'    => 'vestige_sanitize_lines',
				'description' => esc_html__( 'One per line: Label | URL', 'vestige' ),
				'default'     => "Instagram | https://instagram.com\nPinterest | https://pinterest.com\nTikTok | https://tiktok.com",
			),
			'vestige_newsletter_heading' => array(
				'label'   => esc_html__( 'Newsletter band heading', 'vestige' ),
				'default' => 'First access. No noise.',
			),
			'vestige_newsletter_eyebrow' => array(
				'label'   => esc_html__( 'Newsletter band eyebrow', 'vestige' ),
				'default' => 'The Drop List',
			),
		)
	);

	/* --- Colours ------------------------------------------------------------ */
	$add(
		'vestige_colors',
		array(
			'title'    => esc_html__( 'Colours', 'vestige' ),
			'priority' => 20,
		),
		array(
			'vestige_color_ink'    => array(
				'label'    => esc_html__( 'Ink (background / dark)', 'vestige' ),
				'type'     => 'color',
				'sanitize' => 'sanitize_hex_color',
				'default'  => '#101010',
			),
			'vestige_color_bone'   => array(
				'label'    => esc_html__( 'Bone (text / light)', 'vestige' ),
				'type'     => 'color',
				'sanitize' => 'sanitize_hex_color',
				'default'  => '#EDE8E0',
			),
			'vestige_color_accent' => array(
				'label'    => esc_html__( 'Accent (vermilion)', 'vestige' ),
				'type'     => 'color',
				'sanitize' => 'sanitize_hex_color',
				'default'  => '#FF4D00',
			),
		)
	);

	/* --- Hero ------------------------------------------------------------------ */
	$add(
		'vestige_hero',
		array(
			'title'       => esc_html__( 'Homepage — Hero (pattern defaults)', 'vestige' ),
			'description' => esc_html__( 'These values seed the Hero block pattern when the demo import builds the Home page. Afterwards, edit the hero directly on the page in the block editor.', 'vestige' ),
			'priority'    => 30,
		),
		array(
			'vestige_hero_eyebrow'  => array(
				'label'   => esc_html__( 'Eyebrow', 'vestige' ),
				'default' => 'Autumn / Winter — Drop 04',
			),
			'vestige_hero_title_1'  => array(
				'label'   => esc_html__( 'Title line 1', 'vestige' ),
				'default' => 'Wear What',
			),
			'vestige_hero_title_2'  => array(
				'label'   => esc_html__( 'Title line 2 (accent)', 'vestige' ),
				'default' => 'Remains',
			),
			'vestige_hero_lede'     => array(
				'label'    => esc_html__( 'Lede', 'vestige' ),
				'type'     => 'textarea',
				'sanitize' => 'vestige_sanitize_textarea',
				'default'  => 'Dark editorial clothing built to outlast trends — cut in limited runs, stripped of logos, always selvedge denim.',
			),
			'vestige_hero_image'    => array(
				'label'    => esc_html__( 'Hero image (used by the demo import)', 'vestige' ),
				'type'     => 'image',
				'sanitize' => 'esc_url_raw',
				'default'  => '',
			),
			'vestige_stat_1_value'  => array( 'label' => esc_html__( 'Stat 1 value', 'vestige' ), 'default' => '14' ),
			'vestige_stat_1_label'  => array( 'label' => esc_html__( 'Stat 1 label', 'vestige' ), 'default' => 'Pieces' ),
			'vestige_stat_2_value'  => array( 'label' => esc_html__( 'Stat 2 value', 'vestige' ), 'default' => '4.8' ),
			'vestige_stat_2_label'  => array( 'label' => esc_html__( 'Stat 2 label', 'vestige' ), 'default' => 'Avg rating' ),
			'vestige_stat_3_value'  => array( 'label' => esc_html__( 'Stat 3 value', 'vestige' ), 'default' => '2,841' ),
			'vestige_stat_3_label'  => array( 'label' => esc_html__( 'Stat 3 label', 'vestige' ), 'default' => 'Reviews' ),
			'vestige_marquee_text'  => array(
				'label'   => esc_html__( 'Marquee text', 'vestige' ),
				'default' => 'VESTIGE — WEAR WHAT REMAINS — FREE SHIPPING OVER $200 — ',
			),
		)
	);

	/* --- Sections copy ------------------------------------------------------------ */
	$add(
		'vestige_sections',
		array(
			'title'       => esc_html__( 'Homepage — Sections (pattern defaults)', 'vestige' ),
			'description' => esc_html__( 'Default copy for the Featured, Categories, Story, Editorial and Reviews patterns, used when the demo import builds the Home page.', 'vestige' ),
			'priority'    => 40,
		),
		array(
			'vestige_featured_heading' => array(
				'label'   => esc_html__( 'Featured heading', 'vestige' ),
				'default' => 'Featured Remains',
			),
			'vestige_featured_text'    => array(
				'label'    => esc_html__( 'Featured intro', 'vestige' ),
				'type'     => 'textarea',
				'sanitize' => 'vestige_sanitize_textarea',
				'default'  => 'The pieces the drop is built around. Prices first, always — open any piece below for its full story.',
			),
			'vestige_categories_heading' => array(
				'label'   => esc_html__( 'Categories heading', 'vestige' ),
				'default' => 'Shop by remains',
			),
			'vestige_category_tiles'   => array(
				'label'       => esc_html__( 'Category tiles', 'vestige' ),
				'type'        => 'textarea',
				'sanitize'    => 'vestige_sanitize_lines',
				'description' => esc_html__( 'One per line: Name | Label | Blurb. The name must match a product category.', 'vestige' ),
				'default'     => "Outerwear | Start here | Leather, wool, weather armour.\nTailoring | Sharp | Blazers, denim, the column dress.\nEssentials | Daily | Heavy tees and seamless knits.\nFootwear | Ground | Runners, courts, slip-ons.\nObjects | Carry | Packs and frames. Nothing extra.",
			),
			'vestige_story_eyebrow'    => array(
				'label'   => esc_html__( 'Story eyebrow', 'vestige' ),
				'default' => 'The Vestige Method',
			),
			'vestige_story_heading'    => array(
				'label'   => esc_html__( 'Story heading', 'vestige' ),
				'default' => 'Built to be what remains',
			),
			'vestige_story_text'       => array(
				'label'    => esc_html__( 'Story text', 'vestige' ),
				'type'     => 'textarea',
				'sanitize' => 'vestige_sanitize_textarea',
				'default'  => 'Most clothing is designed to be replaced. VESTIGE is designed to be what is left standing — heavy fabrics, honest construction, no logos begging for attention. We cut in limited runs, publish our fabric weights, and price like we plan to see the garment again in ten years.',
			),
			'vestige_method_cards'     => array(
				'label'       => esc_html__( 'Method cards (titles)', 'vestige' ),
				'type'        => 'textarea',
				'sanitize'    => 'vestige_sanitize_textarea',
				'description' => esc_html__( 'One card title per line. Card images come from the demo products and can be swapped in the block editor.', 'vestige' ),
				'default'     => "01 — Heavy cloth only\n02 — Cut in limited runs\n03 — No logos, ever\n04 — Repaired, not replaced",
			),
			'vestige_press_names'      => array(
				'label'       => esc_html__( 'Press names', 'vestige' ),
				'type'        => 'textarea',
				'sanitize'    => 'vestige_sanitize_textarea',
				'description' => esc_html__( 'One name per line.', 'vestige' ),
				'default'     => "HYPEBEAST\nGQ\nDAZED\nHIGHSNOBIETY\ni-D",
			),
			'vestige_editorial_heading' => array(
				'label'   => esc_html__( 'Editorial heading', 'vestige' ),
				'default' => 'Field Notes.',
			),
			'vestige_editorial_notes'  => array(
				'label'       => esc_html__( 'Editorial notes', 'vestige' ),
				'type'        => 'textarea',
				'sanitize'    => 'vestige_sanitize_lines',
				'description' => esc_html__( 'One per line: Eyebrow | Title | Text. Note images are the first three featured products and can be swapped in the block editor.', 'vestige' ),
				'default'     => "Leather | The Relic, six months in | Our cropped jacket after half a year of daily wear — the grain deepens, the vermilion lining appears only in motion.\nWool | A coat that is the outfit | The Monolith was cut oversized on purpose. Under it, anything. Over everything, presence.\nSilk | Half a second behind you | The Column dress is bias-cut so the fabric moves after you do. That delay is the whole design.",
			),
			'vestige_reviews_eyebrow'  => array(
				'label'   => esc_html__( 'Reviews eyebrow', 'vestige' ),
				'default' => 'Word of mouth',
			),
			'vestige_reviews_heading'  => array(
				'label'   => esc_html__( 'Reviews heading', 'vestige' ),
				'default' => 'Worn & sworn by',
			),
			'vestige_reviews_text'     => array(
				'label'    => esc_html__( 'Reviews intro', 'vestige' ),
				'type'     => 'textarea',
				'sanitize' => 'vestige_sanitize_textarea',
				'default'  => '4.8 average across 2,841 verified reviews.',
			),
			'vestige_reviews_quote'    => array(
				'label'    => esc_html__( 'Featured review quote', 'vestige' ),
				'type'     => 'textarea',
				'sanitize' => 'vestige_sanitize_textarea',
				'default'  => 'You can feel the fabric weight the second you pick it up. Cut is exactly as pictured.',
			),
			'vestige_reviews_quote_author' => array(
				'label'   => esc_html__( 'Featured review author', 'vestige' ),
				'default' => 'Mara J., verified buyer',
			),
		)
	);
}
add_action( 'customize_register', 'vestige_customize_register' );
