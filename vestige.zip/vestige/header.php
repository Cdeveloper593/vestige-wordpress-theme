<?php
/**
 * The header: document head, announcement bar, sticky header with
 * wordmark / burger / cart, and the full-screen overlay menu.
 *
 * The overlay menu lists Home / Shop / Checkout (numbered, like the
 * source template) plus the product categories. Buyers can replace it
 * with their own menu under Appearance → Menus ("Primary Menu").
 *
 * @package Vestige
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="profile" href="https://gmpg.org/xfn/11" />
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'vestige' ); ?></a>

<?php $vestige_announcement = (string) vestige_mod( 'vestige_announcement', 'Free shipping over $200 — Drop 04 live now' ); ?>
<?php if ( '' !== trim( $vestige_announcement ) ) : ?>
	<div class="announcement" role="note"><?php echo esc_html( $vestige_announcement ); ?></div>
<?php endif; ?>

<header class="site-header">
	<div class="wrap site-header__in">
		<?php vestige_the_wordmark(); ?>
		<div class="header-actions">
			<button class="burger vestige-menu-toggle" type="button" aria-expanded="false" aria-controls="site-menu">
				<span class="lines" aria-hidden="true"><i></i><i></i><i></i></span>
				<span class="burger-label"><?php esc_html_e( 'Menu', 'vestige' ); ?></span>
			</button>
			<?php vestige_the_cart_button(); ?>
		</div>
	</div>
</header>

<nav id="site-menu" class="site-menu" aria-label="<?php esc_attr_e( 'Main', 'vestige' ); ?>" hidden>
	<div class="wrap">
		<?php if ( has_nav_menu( 'primary' ) ) : ?>
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'container'      => false,
					'menu_class'     => 'menu-list',
					'items_wrap'     => '<ol id="%1$s" class="%2$s">%3$s</ol>',
					'depth'          => 1,
					'link_before'    => '',
				)
			);
			?>
		<?php else : ?>
			<?php
			$vestige_links = array(
				array( 'label' => __( 'Home', 'vestige' ), 'url' => home_url( '/' ), 'current' => is_front_page() ),
				array( 'label' => __( 'Shop', 'vestige' ), 'url' => vestige_shop_url(), 'current' => function_exists( 'is_shop' ) && ( is_shop() || is_singular( 'product' ) || is_tax( 'product_cat' ) ) ),
				array( 'label' => __( 'Checkout', 'vestige' ), 'url' => vestige_checkout_url(), 'current' => function_exists( 'is_checkout' ) && is_checkout() ),
			);
			?>
			<ol>
				<?php foreach ( $vestige_links as $vestige_i => $vestige_link ) : ?>
					<li>
						<a class="menu-link" href="<?php echo esc_url( $vestige_link['url'] ); ?>"<?php echo $vestige_link['current'] ? ' aria-current="page"' : ''; ?>>
							<span class="menu-num"><?php echo esc_html( str_pad( (string) ( $vestige_i + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span>
							<?php echo esc_html( $vestige_link['label'] ); ?>
						</a>
					</li>
				<?php endforeach; ?>
			</ol>
		<?php endif; ?>

		<?php
		$vestige_cats = class_exists( 'WooCommerce' ) ? get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => false,
				'exclude'    => array( (int) get_option( 'default_product_cat', 0 ) ),
			)
		) : array();
		?>
		<?php if ( $vestige_cats && ! is_wp_error( $vestige_cats ) ) : ?>
			<div class="menu-cats">
				<?php foreach ( $vestige_cats as $vestige_cat ) : ?>
					<?php $vestige_cat_link = get_term_link( $vestige_cat ); ?>
					<?php if ( ! is_wp_error( $vestige_cat_link ) ) : ?>
						<a href="<?php echo esc_url( $vestige_cat_link ); ?>"><?php echo esc_html( $vestige_cat->name ); ?></a>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</div>
</nav>
