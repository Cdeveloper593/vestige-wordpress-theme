<?php
/**
 * Block patterns: every homepage section as a native Gutenberg pattern.
 *
 * This is the theme's drag-and-drop layer — no page-builder plugin is
 * needed (or wanted): buyers open Pages → Home and drag, reorder,
 * duplicate or delete sections, editing text and images inline.
 * WooCommerce sections use Woo's own free blocks / shortcodes.
 *
 * The builder functions below return the pattern markup. They are used
 * twice: to register the patterns in the inserter, and by the demo
 * import to assemble the Home page (with media-library image URLs
 * instead of the bundled theme asset URLs).
 *
 * @package Vestige
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Default pattern images (bundled demo assets).
 *
 * @return array<string,string>
 */
function vestige_pattern_default_images() {
	$base = get_template_directory_uri() . '/assets/demo/';
	return array(
		'hero'   => $base . '1490481651871-ab68de25d43d.jpg',
		'story1' => $base . '1521572163474-6864f9cf17ab.jpg',
		'story2' => $base . '1551028719-00167b16eac5.jpg',
		'story3' => $base . '1594633312681-425c7b97ccd1.jpg',
		'story4' => $base . '1434389677669-e08b4cac3105.jpg',
		'note1'  => $base . '1551028719-00167b16eac5.jpg',
		'note2'  => $base . '1539109136881-3be0616acf4b.jpg',
		'note3'  => $base . '1594633312681-425c7b97ccd1.jpg',
	);
}

/**
 * Pick an image URL from the map, falling back to defaults.
 *
 * @param array<string,string> $images Image map.
 * @param string               $key    Key.
 * @return string
 */
function vestige_pattern_image( $images, $key ) {
	if ( isset( $images[ $key ] ) && '' !== $images[ $key ] ) {
		return $images[ $key ];
	}
	$defaults = vestige_pattern_default_images();
	return isset( $defaults[ $key ] ) ? $defaults[ $key ] : '';
}

/**
 * HERO pattern — eyebrow, giant two-line title, lede, CTAs, stats, image.
 *
 * @param array<string,string> $images Image map.
 * @return string Block markup.
 */
function vestige_pattern_hero( $images = array() ) {
	$eyebrow = esc_html( (string) vestige_mod( 'vestige_hero_eyebrow', 'Autumn / Winter — Drop 04' ) );
	$title1  = esc_html( (string) vestige_mod( 'vestige_hero_title_1', 'Wear What' ) );
	$title2  = esc_html( (string) vestige_mod( 'vestige_hero_title_2', 'Remains' ) );
	$lede    = esc_html( (string) vestige_mod( 'vestige_hero_lede', 'Dark editorial clothing built to outlast trends — cut in limited runs, stripped of logos, always selvedge denim.' ) );
	$img     = esc_url( vestige_pattern_image( $images, 'hero' ) );
	$shop    = esc_url( vestige_shop_url() );
	$outer   = esc_url( vestige_category_url( 'outerwear' ) );

	$stats_html = '';
	foreach ( vestige_hero_stats() as $stat ) {
		$stats_html .= '<!-- wp:group --><div class="wp-block-group">'
			. '<!-- wp:paragraph {"className":"stat-value"} --><p class="stat-value">' . esc_html( $stat['value'] ) . '</p><!-- /wp:paragraph -->'
			. '<!-- wp:paragraph {"className":"stat-label"} --><p class="stat-label">' . esc_html( $stat['label'] ) . '</p><!-- /wp:paragraph -->'
			. '</div><!-- /wp:group -->';
	}

	return '<!-- wp:group {"className":"vestige-hero","layout":{"type":"constrained"}} -->'
		. '<div class="wp-block-group vestige-hero">'
		. '<!-- wp:html --><div class="vestige-grain" aria-hidden="true"></div><!-- /wp:html -->'
		. '<!-- wp:group {"className":"vestige-hero__grid"} --><div class="wp-block-group vestige-hero__grid">'
		. '<!-- wp:group --><div class="wp-block-group">'
		. '<!-- wp:paragraph {"className":"eyebrow"} --><p class="eyebrow">' . $eyebrow . '</p><!-- /wp:paragraph -->'
		. '<!-- wp:heading {"level":1,"className":"hero-title"} --><h1 class="wp-block-heading hero-title">' . $title1 . ' <span class="line-accent">' . $title2 . '</span></h1><!-- /wp:heading -->'
		. '<!-- wp:paragraph {"className":"lede"} --><p class="lede">' . $lede . '</p><!-- /wp:paragraph -->'
		. '<!-- wp:buttons {"className":"hero-ctas"} --><div class="wp-block-buttons hero-ctas">'
		. '<!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="' . $shop . '">Shop the drop</a></div><!-- /wp:button -->'
		. '<!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="' . $outer . '">Outerwear</a></div><!-- /wp:button -->'
		. '</div><!-- /wp:buttons -->'
		. '<!-- wp:group {"className":"hero-stats"} --><div class="wp-block-group hero-stats">' . $stats_html . '</div><!-- /wp:group -->'
		. '</div><!-- /wp:group -->'
		. '<!-- wp:image {"className":"hero-media ph","sizeSlug":"vestige-hero"} --><figure class="wp-block-image size-vestige-hero hero-media ph"><img src="' . $img . '" alt="Editorial fashion look from the current drop"/></figure><!-- /wp:image -->'
		. '</div><!-- /wp:group -->'
		. '</div><!-- /wp:group -->';
}

/**
 * MARQUEE pattern — scrolling strip (CSS animation, duplicated track).
 *
 * @return string Block markup.
 */
function vestige_pattern_marquee() {
	$text  = esc_html( (string) vestige_mod( 'vestige_marquee_text', 'VESTIGE — WEAR WHAT REMAINS — FREE SHIPPING OVER $200 — ' ) );
	$track = '<!-- wp:paragraph {"className":"marquee-track"} --><p class="marquee-track">' . $text . '</p><!-- /wp:paragraph -->';
	return '<!-- wp:group {"className":"vestige-marquee"} --><div class="wp-block-group vestige-marquee">'
		. $track . $track
		. '</div><!-- /wp:group -->';
}

/**
 * FEATURED PRODUCTS pattern — Woo [products] shortcode (renders through
 * the theme's content-product.php card), so the section always reflects
 * the live catalogue and its featured flags.
 *
 * @return string Block markup.
 */
function vestige_pattern_featured() {
	$heading = esc_html( (string) vestige_mod( 'vestige_featured_heading', 'Featured Remains' ) );
	$text    = esc_html( (string) vestige_mod( 'vestige_featured_text', 'The pieces the drop is built around. Prices first, always — open any piece below for its full story.' ) );
	$shop    = esc_url( vestige_shop_url() );
	return '<!-- wp:group {"className":"section-pad vestige-featured","layout":{"type":"constrained"}} -->'
		. '<div class="wp-block-group section-pad vestige-featured">'
		. '<!-- wp:heading {"className":"section-head"} --><h2 class="wp-block-heading section-head">' . $heading . '</h2><!-- /wp:heading -->'
		. '<!-- wp:paragraph {"className":"lede"} --><p class="lede">' . $text . '</p><!-- /wp:paragraph -->'
		. '<!-- wp:shortcode -->[products limit="6" columns="3" visibility="featured" orderby="menu_order"]<!-- /wp:shortcode -->'
		. '<!-- wp:buttons --><div class="wp-block-buttons">'
		. '<!-- wp:button {"className":"is-style-outline"} --><div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="' . $shop . '">View all pieces</a></div><!-- /wp:button -->'
		. '</div><!-- /wp:buttons -->'
		. '</div><!-- /wp:group -->';
}

/**
 * CATEGORIES pattern — bento tiles for each product category.
 *
 * @return string Block markup.
 */
function vestige_pattern_categories() {
	$heading = esc_html( (string) vestige_mod( 'vestige_categories_heading', 'Shop by remains' ) );
	$tiles   = '';
	foreach ( vestige_category_tiles() as $tile ) {
		$url    = esc_url( vestige_category_url( $tile['slug'] ) );
		$tiles .= '<!-- wp:group {"className":"cat-tile"} --><div class="wp-block-group cat-tile">'
			. '<!-- wp:paragraph {"className":"cat-label"} --><p class="cat-label">' . esc_html( $tile['label'] ) . '</p><!-- /wp:paragraph -->'
			. '<!-- wp:heading {"level":3} --><h3 class="wp-block-heading"><a href="' . $url . '">' . esc_html( $tile['name'] ) . '</a></h3><!-- /wp:heading -->'
			. '<!-- wp:paragraph --><p>' . esc_html( $tile['blurb'] ) . '</p><!-- /wp:paragraph -->'
			. '</div><!-- /wp:group -->';
	}
	$shop   = esc_url( vestige_shop_url() );
	$tiles .= '<!-- wp:group {"className":"cat-tile"} --><div class="wp-block-group cat-tile">'
		. '<!-- wp:paragraph {"className":"cat-label"} --><p class="cat-label">All</p><!-- /wp:paragraph -->'
		. '<!-- wp:heading {"level":3} --><h3 class="wp-block-heading"><a href="' . $shop . '">Everything</a></h3><!-- /wp:heading -->'
		. '<!-- wp:paragraph --><p>The full drop, unfiltered.</p><!-- /wp:paragraph -->'
		. '</div><!-- /wp:group -->';

	return '<!-- wp:group {"className":"section-pad vestige-categories","layout":{"type":"constrained"}} -->'
		. '<div class="wp-block-group section-pad vestige-categories">'
		. '<!-- wp:heading --><h2 class="wp-block-heading">' . $heading . '</h2><!-- /wp:heading -->'
		. '<!-- wp:group {"className":"cat-bento"} --><div class="wp-block-group cat-bento">' . $tiles . '</div><!-- /wp:group -->'
		. '</div><!-- /wp:group -->';
}

/**
 * STORY pattern — "The Vestige Method": sticky copy + press names on
 * the left, four method cards with product images on the right.
 *
 * @param array<string,string> $images Image map.
 * @return string Block markup.
 */
function vestige_pattern_story( $images = array() ) {
	$eyebrow = esc_html( (string) vestige_mod( 'vestige_story_eyebrow', 'The Vestige Method' ) );
	$heading = esc_html( (string) vestige_mod( 'vestige_story_heading', 'Built to be what remains' ) );
	$text    = esc_html( (string) vestige_mod( 'vestige_story_text', 'Most clothing is designed to be replaced. VESTIGE is designed to be what is left standing — heavy fabrics, honest construction, no logos begging for attention. We cut in limited runs, publish our fabric weights, and price like we plan to see the garment again in ten years.' ) );

	$press = '';
	foreach ( vestige_press_names() as $name ) {
		$press .= '<span>' . esc_html( $name ) . '</span>';
	}

	$titles = vestige_lines( (string) vestige_mod( 'vestige_method_cards', "01 — Heavy cloth only\n02 — Cut in limited runs\n03 — No logos, ever\n04 — Repaired, not replaced" ) );
	$cards  = '';
	foreach ( $titles as $i => $title ) {
		$key    = 'story' . ( $i + 1 );
		$img    = esc_url( vestige_pattern_image( $images, $key ) );
		$cards .= '<!-- wp:group {"className":"method-card"} --><div class="wp-block-group method-card">'
			. '<!-- wp:image {"className":"ph","sizeSlug":"vestige-wide"} --><figure class="wp-block-image size-vestige-wide ph"><img src="' . $img . '" alt=""/></figure><!-- /wp:image -->'
			. '<!-- wp:heading {"level":3} --><h3 class="wp-block-heading">' . esc_html( $title ) . '</h3><!-- /wp:heading -->'
			. '</div><!-- /wp:group -->';
	}

	return '<!-- wp:group {"className":"story-section section-pad","layout":{"type":"constrained"}} -->'
		. '<div class="wp-block-group story-section section-pad">'
		. '<!-- wp:group {"className":"story-grid"} --><div class="wp-block-group story-grid">'
		. '<!-- wp:group {"className":"story-sticky"} --><div class="wp-block-group story-sticky">'
		. '<!-- wp:paragraph {"className":"eyebrow"} --><p class="eyebrow">' . $eyebrow . '</p><!-- /wp:paragraph -->'
		. '<!-- wp:heading --><h2 class="wp-block-heading">' . $heading . '</h2><!-- /wp:heading -->'
		. '<!-- wp:paragraph {"className":"lede"} --><p class="lede">' . $text . '</p><!-- /wp:paragraph -->'
		. '<!-- wp:html --><div class="press-loop" aria-label="Press mentions">' . $press . '</div><!-- /wp:html -->'
		. '</div><!-- /wp:group -->'
		. '<!-- wp:group {"className":"method-cards"} --><div class="wp-block-group method-cards">' . $cards . '</div><!-- /wp:group -->'
		. '</div><!-- /wp:group -->'
		. '</div><!-- /wp:group -->';
}

/**
 * EDITORIAL pattern — "Field Notes.": three full-bleed notes with the
 * source's background colours (#1c1c1c / accent / bone).
 *
 * @param array<string,string> $images Image map.
 * @return string Block markup.
 */
function vestige_pattern_editorial( $images = array() ) {
	$heading = esc_html( (string) vestige_mod( 'vestige_editorial_heading', 'Field Notes.' ) );
	$raw     = (string) vestige_mod(
		'vestige_editorial_notes',
		"Leather | The Relic, six months in | Our cropped jacket after half a year of daily wear — the grain deepens, the vermilion lining appears only in motion.\nWool | A coat that is the outfit | The Monolith was cut oversized on purpose. Under it, anything. Over everything, presence.\nSilk | Half a second behind you | The Column dress is bias-cut so the fabric moves after you do. That delay is the whole design."
	);
	$bgs = array( '#1c1c1c', '#FF4D00', '#EDE8E0' );
	$fgs = array( '#EDE8E0', '#FFFFFF', '#101010' );

	$notes = '';
	foreach ( vestige_lines( $raw ) as $i => $line ) {
		$parts = array_map( 'trim', explode( '|', $line ) );
		if ( count( $parts ) < 3 ) {
			continue;
		}
		$bg  = $bgs[ $i % 3 ];
		$fg  = $fgs[ $i % 3 ];
		$img = esc_url( vestige_pattern_image( $images, 'note' . ( $i + 1 ) ) );
		$notes .= '<!-- wp:group {"className":"editorial-note","style":{"color":{"background":"' . $bg . '","text":"' . $fg . '"}}} -->'
			. '<div class="wp-block-group editorial-note has-text-color has-background" style="color:' . $fg . ';background-color:' . $bg . '">'
			. '<!-- wp:group {"className":"editorial-note__in"} --><div class="wp-block-group editorial-note__in">'
			. '<!-- wp:group --><div class="wp-block-group">'
			. '<!-- wp:paragraph {"className":"eyebrow"} --><p class="eyebrow">' . esc_html( $parts[0] ) . '</p><!-- /wp:paragraph -->'
			. '<!-- wp:heading {"level":3} --><h3 class="wp-block-heading">' . esc_html( $parts[1] ) . '</h3><!-- /wp:heading -->'
			. '<!-- wp:paragraph --><p>' . esc_html( $parts[2] ) . '</p><!-- /wp:paragraph -->'
			. '</div><!-- /wp:group -->'
			. '<!-- wp:image {"className":"ph","sizeSlug":"large"} --><figure class="wp-block-image size-large ph"><img src="' . $img . '" alt=""/></figure><!-- /wp:image -->'
			. '</div><!-- /wp:group -->'
			. '</div><!-- /wp:group -->';
	}

	return '<!-- wp:group {"className":"section-pad","layout":{"type":"constrained"}} -->'
		. '<div class="wp-block-group section-pad">'
		. '<!-- wp:heading --><h2 class="wp-block-heading">' . $heading . '</h2><!-- /wp:heading -->'
		. $notes
		. '</div><!-- /wp:group -->';
}

/**
 * REVIEWS pattern — heading, intro and the featured review quote.
 * (Live product reviews live on the product pages, as Woo reviews.)
 *
 * @return string Block markup.
 */
function vestige_pattern_reviews() {
	$eyebrow = esc_html( (string) vestige_mod( 'vestige_reviews_eyebrow', 'Word of mouth' ) );
	$heading = esc_html( (string) vestige_mod( 'vestige_reviews_heading', 'Worn & sworn by' ) );
	$text    = esc_html( (string) vestige_mod( 'vestige_reviews_text', '4.8 average across 2,841 verified reviews.' ) );
	$quote   = esc_html( (string) vestige_mod( 'vestige_reviews_quote', 'You can feel the fabric weight the second you pick it up. Cut is exactly as pictured.' ) );
	$author  = esc_html( (string) vestige_mod( 'vestige_reviews_quote_author', 'Mara J., verified buyer' ) );

	return '<!-- wp:group {"className":"section-pad vestige-reviews","layout":{"type":"constrained"}} -->'
		. '<div class="wp-block-group section-pad vestige-reviews">'
		. '<!-- wp:paragraph {"className":"eyebrow"} --><p class="eyebrow">' . $eyebrow . '</p><!-- /wp:paragraph -->'
		. '<!-- wp:heading --><h2 class="wp-block-heading">' . $heading . '</h2><!-- /wp:heading -->'
		. '<!-- wp:paragraph {"className":"lede"} --><p class="lede">' . $text . '</p><!-- /wp:paragraph -->'
		. '<!-- wp:quote {"className":"reviews-quote"} --><blockquote class="wp-block-quote reviews-quote">'
		. '<!-- wp:paragraph --><p>“' . $quote . '”</p><!-- /wp:paragraph -->'
		. '<cite>— ' . $author . '</cite></blockquote><!-- /wp:quote -->'
		. '</div><!-- /wp:group -->';
}

/**
 * NEWSLETTER pattern — the footer band as a reusable pattern. The form
 * posts to the theme's own admin-post handler (no plugin, no service).
 *
 * @return string Block markup.
 */
function vestige_pattern_newsletter() {
	$eyebrow = esc_html( (string) vestige_mod( 'vestige_newsletter_eyebrow', 'The Drop List' ) );
	$heading = esc_html( (string) vestige_mod( 'vestige_newsletter_heading', 'First access. No noise.' ) );
	$action  = esc_url( admin_url( 'admin-post.php' ) );
	$form    = '<form class="newsletter-form" method="post" action="' . $action . '">'
		. '<input type="hidden" name="action" value="vestige_newsletter" />'
		. '<label class="screen-reader-text" for="vestige-nl-email-p">' . esc_html__( 'Email address', 'vestige' ) . '</label>'
		. '<input id="vestige-nl-email-p" type="email" name="email" required placeholder="your@email.com" />'
		. '<button type="submit" class="btn-primary">' . esc_html__( 'Join', 'vestige' ) . '</button>'
		. '</form>';

	return '<!-- wp:group {"className":"newsletter-band"} -->'
		. '<div class="wp-block-group newsletter-band vestige-plasma">'
		. '<!-- wp:paragraph {"className":"eyebrow"} --><p class="eyebrow">' . $eyebrow . '</p><!-- /wp:paragraph -->'
		. '<!-- wp:heading --><h2 class="wp-block-heading">' . $heading . '</h2><!-- /wp:heading -->'
		. '<!-- wp:html -->' . $form . '<!-- /wp:html -->'
		. '</div><!-- /wp:group -->';
}

/**
 * The full Home page content: all patterns in source order.
 *
 * @param array<string,string> $images Image map (media library URLs).
 * @return string Block markup.
 */
function vestige_home_content( $images = array() ) {
	return implode(
		"\n\n",
		array(
			vestige_pattern_hero( $images ),
			vestige_pattern_marquee(),
			vestige_pattern_featured(),
			vestige_pattern_categories(),
			vestige_pattern_story( $images ),
			vestige_pattern_editorial( $images ),
			vestige_pattern_reviews(),
			vestige_pattern_newsletter(),
		)
	);
}

/**
 * Register the pattern category and all patterns in the inserter.
 */
function vestige_register_patterns() {
	if ( ! function_exists( 'register_block_pattern' ) ) {
		return;
	}
	register_block_pattern_category(
		'vestige',
		array( 'label' => esc_html__( 'Vestige', 'vestige' ) )
	);

	$patterns = array(
		'vestige/hero'       => array(
			'title'   => __( 'Vestige — Hero', 'vestige' ),
			'content' => vestige_pattern_hero(),
		),
		'vestige/marquee'    => array(
			'title'   => __( 'Vestige — Marquee', 'vestige' ),
			'content' => vestige_pattern_marquee(),
		),
		'vestige/featured-products' => array(
			'title'   => __( 'Vestige — Featured Products', 'vestige' ),
			'content' => vestige_pattern_featured(),
		),
		'vestige/categories' => array(
			'title'   => __( 'Vestige — Categories', 'vestige' ),
			'content' => vestige_pattern_categories(),
		),
		'vestige/story'      => array(
			'title'   => __( 'Vestige — Story / Method', 'vestige' ),
			'content' => vestige_pattern_story(),
		),
		'vestige/editorial'  => array(
			'title'   => __( 'Vestige — Editorial / Field Notes', 'vestige' ),
			'content' => vestige_pattern_editorial(),
		),
		'vestige/reviews'    => array(
			'title'   => __( 'Vestige — Reviews', 'vestige' ),
			'content' => vestige_pattern_reviews(),
		),
		'vestige/newsletter' => array(
			'title'   => __( 'Vestige — Newsletter Band', 'vestige' ),
			'content' => vestige_pattern_newsletter(),
		),
	);

	foreach ( $patterns as $name => $pattern ) {
		register_block_pattern(
			$name,
			array(
				'title'      => $pattern['title'],
				'categories' => array( 'vestige' ),
				'content'    => $pattern['content'],
			)
		);
	}
}
add_action( 'init', 'vestige_register_patterns' );

/**
 * Motion hooks are injected at render time, never stored in block markup.
 *
 * The patterns above intentionally keep their saved markup to attributes
 * the Group block itself supports: anything extra on the wrapper element
 * (a data attribute, aria-hidden) makes Gutenberg flag the block as
 * "invalid content" in the editor and offer a recovery that strips it.
 * Instead, this filter adds the theme's motion/ARIA hooks to the rendered
 * HTML of pattern groups, keyed by their (supported) class names — so the
 * front end gets exactly the hooks theme.js expects while buyers can edit,
 * move and duplicate the sections without validation warnings.
 *
 * @param string $block_content Rendered block HTML.
 * @param array  $block         Parsed block.
 * @return string
 */
function vestige_group_motion_hooks( $block_content, $block ) {
	if ( ! isset( $block['blockName'] ) || 'core/group' !== $block['blockName'] || ! isset( $block['attrs']['className'] ) ) {
		return $block_content;
	}
	$tokens = array_filter( preg_split( '/\s+/', (string) $block['attrs']['className'] ) );
	$map    = array(
		'vestige-hero'       => 'data-vestige-reveal="hero"',
		'vestige-marquee'    => 'aria-hidden="true"',
		'vestige-featured'   => 'data-vestige-reveal="rise"',
		'vestige-categories' => 'data-vestige-reveal="rise"',
		'cat-tile'           => 'data-vestige-reveal="fade"',
		'story-sticky'       => 'data-vestige-reveal="blur"',
		'method-card'        => 'data-vestige-reveal="rise"',
		'editorial-note'     => 'data-vestige-reveal="rise"',
		'vestige-reviews'    => 'data-vestige-reveal="blur"',
		'newsletter-band'    => 'data-vestige-reveal="fade"',
	);
	foreach ( $map as $class => $attribute ) {
		if ( in_array( $class, $tokens, true ) ) {
			// Insert into the group's opening tag (its first element).
			return preg_replace( '/<div\s/', '<div ' . $attribute . ' ', $block_content, 1 );
		}
	}
	return $block_content;
}
add_filter( 'render_block', 'vestige_group_motion_hooks', 10, 2 );
