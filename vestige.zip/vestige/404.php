<?php
/**
 * 404 — "Piece not found", in the source template's voice.
 *
 * @package Vestige
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="content" class="site-main">
	<div class="wrap content-wrap" style="text-align:center;padding-block:6rem">
		<p class="eyebrow">404</p>
		<h1 class="entry-title"><?php esc_html_e( 'Piece not found', 'vestige' ); ?></h1>
		<p class="lede" style="margin-inline:auto"><?php esc_html_e( 'That remnant has already been claimed. The drop, however, remains.', 'vestige' ); ?></p>
		<p style="margin-top:2rem">
			<a class="btn-primary" href="<?php echo esc_url( vestige_shop_url() ); ?>"><?php esc_html_e( 'Back to shop', 'vestige' ); ?></a>
			<a class="btn-ghost" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'vestige' ); ?></a>
		</p>
		<div style="max-width:30rem;margin:3rem auto 0"><?php get_search_form(); ?></div>
	</div>
</main>

<?php
get_footer();
