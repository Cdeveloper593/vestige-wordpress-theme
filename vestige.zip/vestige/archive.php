<?php
/**
 * Archive template (categories, tags, dates, authors).
 *
 * @package Vestige
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="content" class="site-main">
	<div class="wrap content-wrap">
		<header class="page-header" style="margin-bottom:2.5rem">
			<?php the_archive_title( '<h1 class="entry-title">', '</h1>' ); ?>
			<?php the_archive_description( '<p class="lede">', '</p>' ); ?>
		</header>
		<?php if ( have_posts() ) : ?>
			<div class="blog-grid">
				<?php
				while ( have_posts() ) :
					the_post();
					?>
					<article id="post-<?php the_ID(); ?>" <?php post_class( 'post-card' ); ?>>
						<?php if ( has_post_thumbnail() ) : ?>
							<div class="ph">
								<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'vestige-wide' ); ?></a>
							</div>
						<?php endif; ?>
						<p class="entry-meta"><?php vestige_posted_on(); ?></p>
						<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
						<div class="entry-summary"><?php the_excerpt(); ?></div>
					</article>
					<?php
				endwhile;
				?>
			</div>
			<?php the_posts_pagination(); ?>
		<?php else : ?>
			<p class="lede"><?php esc_html_e( 'Nothing remains in this archive.', 'vestige' ); ?></p>
		<?php endif; ?>
	</div>
</main>

<?php
get_footer();
