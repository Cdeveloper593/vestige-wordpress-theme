<?php
/**
 * WooCommerce integration: wrappers, loop overrides, the AJAX cart
 * drawer, shop filters, product meta (badge / details), and the
 * newsletter handler. Everything degrades gracefully when
 * WooCommerce is not active — the theme still runs as a blog.
 *
 * @package Vestige
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ---------------------------------------------------------------------------
   Wrappers & default-output cleanup
   --------------------------------------------------------------------------- */

/**
 * Swap WooCommerce's wrappers for the theme's.
 */
function vestige_woo_wrappers() {
	remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
	remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
	remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );
	remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );

	add_action( 'woocommerce_before_main_content', 'vestige_woo_wrapper_start', 10 );
	add_action( 'woocommerce_after_main_content', 'vestige_woo_wrapper_end', 10 );

	// The product card (woocommerce/content-product.php) is hand-built,
	// so remove the default loop pieces it replaces.
	remove_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open', 10 );
	remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5 );
	remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10 );
	remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10 );
	remove_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title', 10 );
	remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );
	remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10 );
	remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );
}
add_action( 'init', 'vestige_woo_wrappers' );

/**
 * Open the theme wrapper for Woo pages that use the default loop
 * (cart, checkout, my-account…).
 */
function vestige_woo_wrapper_start() {
	echo '<main id="content" class="site-main"><div class="wrap content-wrap">';
}

/**
 * Close the theme wrapper.
 */
function vestige_woo_wrapper_end() {
	echo '</div></main>';
}

/**
 * Twelve products per shop page, like a tight drop — not a warehouse.
 *
 * @param int $per_page Default.
 * @return int
 */
function vestige_woo_products_per_page( $per_page ) {
	return 12;
}
add_filter( 'loop_shop_per_page', 'vestige_woo_products_per_page' );

/**
 * Three columns in the loop (the shortcode honours its own columns).
 *
 * @param int $cols Default.
 * @return int
 */
function vestige_woo_loop_columns( $cols ) {
	return 3;
}
add_filter( 'loop_shop_columns', 'vestige_woo_loop_columns' );

/* ---------------------------------------------------------------------------
   Shop filters: max price (rating / price / name sorts are native Woo
   orderby values driven by the sidebar form in archive-product.php).
   --------------------------------------------------------------------------- */

/**
 * Apply the sidebar's max-price filter to the shop query.
 *
 * @param WP_Query $query Product query.
 */
function vestige_woo_product_query( $query ) {
	if ( ! isset( $_GET['max_price'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- public catalogue filter.
		return;
	}
	$max = abs( (float) wp_unslash( $_GET['max_price'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( $max <= 0 ) {
		return;
	}
	$meta_query = (array) $query->get( 'meta_query' );
	$meta_query[] = array(
		'key'     => '_price',
		'value'   => $max,
		'compare' => '<=',
		'type'    => 'DECIMAL(10,2)',
	);
	$query->set( 'meta_query', $meta_query );
}
add_action( 'woocommerce_product_query', 'vestige_woo_product_query' );

/* ---------------------------------------------------------------------------
   Product meta: badge chip + "Details" list (product edit screen)
   --------------------------------------------------------------------------- */

/**
 * Register the Vestige meta box on the product edit screen.
 */
function vestige_product_meta_boxes() {
	add_meta_box(
		'vestige-product-meta',
		__( 'Vestige — Badge & Details', 'vestige' ),
		'vestige_product_meta_box_render',
		'product',
		'normal',
		'default'
	);
}
add_action( 'add_meta_boxes', 'vestige_product_meta_boxes' );

/**
 * Render the meta box.
 *
 * @param WP_Post $post Product.
 */
function vestige_product_meta_box_render( $post ) {
	wp_nonce_field( 'vestige_product_meta', 'vestige_product_meta_nonce' );
	$badge   = (string) get_post_meta( $post->ID, '_vestige_badge', true );
	$details = (string) get_post_meta( $post->ID, '_vestige_details', true );
	?>
	<p>
		<label for="vestige_badge"><strong><?php esc_html_e( 'Badge chip (shown on the card and product page, e.g. "Icon", "New", "Bestseller")', 'vestige' ); ?></strong></label><br />
		<input type="text" id="vestige_badge" name="vestige_badge" value="<?php echo esc_attr( $badge ); ?>" class="regular-text" />
	</p>
	<p>
		<label for="vestige_details"><strong><?php esc_html_e( 'Details list (one detail per line — shown as the bullet list on the product page)', 'vestige' ); ?></strong></label><br />
		<textarea id="vestige_details" name="vestige_details" rows="5" class="large-text"><?php echo esc_textarea( $details ); ?></textarea>
	</p>
	<?php
}

/**
 * Save the meta box.
 *
 * @param int $post_id Product ID.
 */
function vestige_save_product_meta( $post_id ) {
	if ( ! isset( $_POST['vestige_product_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['vestige_product_meta_nonce'] ) ), 'vestige_product_meta' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	if ( isset( $_POST['vestige_badge'] ) ) {
		update_post_meta( $post_id, '_vestige_badge', sanitize_text_field( wp_unslash( $_POST['vestige_badge'] ) ) );
	}
	if ( isset( $_POST['vestige_details'] ) ) {
		update_post_meta( $post_id, '_vestige_details', sanitize_textarea_field( wp_unslash( $_POST['vestige_details'] ) ) );
	}
}
add_action( 'save_post_product', 'vestige_save_product_meta' );

/**
 * The details list for a product, as an array of lines.
 *
 * @param int $product_id Product ID.
 * @return string[]
 */
function vestige_product_details( $product_id ) {
	return vestige_lines( (string) get_post_meta( $product_id, '_vestige_details', true ) );
}

/**
 * Display review count for cards: the count stored by the demo import
 * (matching the source template's catalogue numbers) when present,
 * otherwise WooCommerce's real review count.
 *
 * @param WC_Product $product Product.
 * @return int
 */
function vestige_review_count( $product ) {
	$stored = (int) get_post_meta( $product->get_id(), '_vestige_review_count', true );
	if ( $stored > 0 ) {
		return $stored;
	}
	return (int) $product->get_review_count();
}

/**
 * Colour hex for a pa_colour term (term meta set by the demo import,
 * editable via a small field on the term edit screen).
 *
 * @param int $term_id Term ID.
 * @return string Hex colour or ''.
 */
function vestige_colour_hex( $term_id ) {
	$hex = sanitize_hex_color( (string) get_term_meta( $term_id, 'vestige_hex', true ) );
	return $hex ? $hex : '';
}

/**
 * Add the hex field to the Colour attribute term screens.
 *
 * @param WP_Term $term Term (edit screen only).
 */
function vestige_colour_term_field( $term = null ) {
	$value = $term ? vestige_colour_hex( $term->term_id ) : '';
	?>
	<div class="form-field">
		<label for="vestige_hex"><?php esc_html_e( 'Swatch colour (hex)', 'vestige' ); ?></label>
		<input type="text" id="vestige_hex" name="vestige_hex" value="<?php echo esc_attr( $value ); ?>" placeholder="#101010" />
		<p class="description"><?php esc_html_e( 'Used for the colour swatches on the product page.', 'vestige' ); ?></p>
	</div>
	<?php
}
add_action( 'pa_colour_add_form_fields', 'vestige_colour_term_field' );
add_action( 'pa_colour_edit_form_fields', 'vestige_colour_term_field' );

/**
 * Save the hex term meta.
 *
 * @param int $term_id Term ID.
 */
function vestige_save_colour_term( $term_id ) {
	if ( isset( $_POST['vestige_hex'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- term screens carry their own nonce in core; value sanitized below.
		$hex = sanitize_hex_color( wp_unslash( $_POST['vestige_hex'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( $hex ) {
			update_term_meta( $term_id, 'vestige_hex', $hex );
		} else {
			delete_term_meta( $term_id, 'vestige_hex' );
		}
	}
}
add_action( 'created_pa_colour', 'vestige_save_colour_term' );
add_action( 'edited_pa_colour', 'vestige_save_colour_term' );

/* ---------------------------------------------------------------------------
   Cart drawer
   --------------------------------------------------------------------------- */

/**
 * HTML for the drawer's dynamic body (items / progress / subtotal).
 * Re-rendered server-side and swapped in by theme.js after AJAX
 * updates, and shipped as a Woo fragment so add-to-cart refreshes it.
 *
 * @return string
 */
function vestige_drawer_body_html() {
	if ( ! class_exists( 'WooCommerce' ) || ! WC()->cart ) {
		return '';
	}
	$cart      = WC()->cart;
	$threshold = vestige_free_shipping_threshold();
	$subtotal  = (float) $cart->get_subtotal();
	$remaining = max( 0, $threshold - $subtotal );
	$pct       = $threshold > 0 ? min( 100, ( $subtotal / $threshold ) * 100 ) : 100;

	ob_start();
	if ( $cart->is_empty() ) {
		?>
		<div class="vestige-drawer-empty">
			<div class="empty-stack" aria-hidden="true">
				<span class="stack-card stack-1"><?php esc_html_e( 'Outerwear', 'vestige' ); ?></span>
				<span class="stack-card stack-2"><?php esc_html_e( 'Essentials', 'vestige' ); ?></span>
				<span class="stack-card stack-3"><?php esc_html_e( 'Footwear', 'vestige' ); ?></span>
			</div>
			<p class="text-sand"><?php esc_html_e( 'Your cart is empty. Remains to be filled.', 'vestige' ); ?></p>
			<a class="btn-primary" href="<?php echo esc_url( vestige_shop_url() ); ?>"><?php esc_html_e( 'Shop the drop', 'vestige' ); ?></a>
		</div>
		<?php
		return ob_get_clean();
	}
	?>
	<div class="vestige-ship-meter">
		<p class="ship-status" role="status">
			<?php if ( $remaining > 0 ) : ?>
				<?php
				printf(
					/* translators: %s: formatted amount still needed for free shipping. */
					esc_html__( 'Add %s more for free shipping', 'vestige' ),
					'<strong>' . wp_kses_post( wc_price( $remaining ) ) . '</strong>'
				);
				?>
			<?php else : ?>
				<?php esc_html_e( 'Free shipping unlocked', 'vestige' ); ?>
			<?php endif; ?>
		</p>
		<div class="ship-bar" aria-hidden="true"><div class="ship-fill" style="width:<?php echo esc_attr( (string) $pct ); ?>%"></div></div>
	</div>

	<ul class="vestige-drawer-items">
		<?php
		foreach ( $cart->get_cart() as $key => $item ) {
			$product = $item['data'];
			if ( ! $product || ! $product->exists() || $item['quantity'] <= 0 ) {
				continue;
			}
			$name  = $product->get_name();
			$attrs = array();
			if ( ! empty( $item['variation'] ) && is_array( $item['variation'] ) ) {
				foreach ( $item['variation'] as $attr => $value ) {
					$term = get_term_by( 'slug', $value, str_replace( 'attribute_', '', $attr ) );
					$attrs[] = $term ? $term->name : $value;
				}
			}
			$thumb = $product->get_image( 'thumbnail' );
			?>
			<li class="drawer-item" data-key="<?php echo esc_attr( $key ); ?>">
				<div class="ph drawer-thumb"><?php echo wp_kses_post( $thumb ); ?></div>
				<div class="drawer-item-main">
					<p class="drawer-item-name"><?php echo esc_html( $name ); ?></p>
					<p class="drawer-item-meta">
						<?php echo esc_html( implode( ' · ', $attrs ) ); ?>
						<?php echo $attrs ? ' · ' : ''; ?>
						<?php echo wp_kses_post( wc_price( (float) $product->get_price() ) ); ?>
					</p>
					<div class="drawer-qty">
						<button type="button" class="qty-btn vestige-qty" data-key="<?php echo esc_attr( $key ); ?>" data-delta="-1" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: product name. */ __( 'Decrease quantity of %s', 'vestige' ), $name ) ); ?>">−</button>
						<span class="qty-value" role="status"><?php echo esc_html( (string) $item['quantity'] ); ?></span>
						<button type="button" class="qty-btn vestige-qty" data-key="<?php echo esc_attr( $key ); ?>" data-delta="1" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: product name. */ __( 'Increase quantity of %s', 'vestige' ), $name ) ); ?>">+</button>
						<button type="button" class="drawer-remove vestige-remove" data-key="<?php echo esc_attr( $key ); ?>" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: product name. */ __( 'Remove %s from cart', 'vestige' ), $name ) ); ?>"><?php esc_html_e( 'Remove', 'vestige' ); ?></button>
					</div>
				</div>
				<p class="drawer-item-total"><?php echo wp_kses_post( wc_price( (float) $product->get_price() * $item['quantity'] ) ); ?></p>
			</li>
			<?php
		}
		?>
	</ul>

	<div class="vestige-drawer-foot">
		<p class="drawer-subtotal">
			<span><?php esc_html_e( 'Subtotal', 'vestige' ); ?></span>
			<span><?php echo wp_kses_post( wc_price( $subtotal ) ); ?></span>
		</p>
		<p class="drawer-note"><?php esc_html_e( 'Shipping calculated at checkout.', 'vestige' ); ?></p>
		<a class="btn-primary drawer-checkout" href="<?php echo esc_url( vestige_checkout_url() ); ?>"><?php esc_html_e( 'Checkout', 'vestige' ); ?></a>
		<a class="drawer-view-cart" href="<?php echo esc_url( wc_get_cart_url() ); ?>"><?php esc_html_e( 'View cart', 'vestige' ); ?></a>
	</div>
	<?php
	return ob_get_clean();
}

/**
 * Render the drawer shell (called from footer.php on every page).
 */
function vestige_render_cart_drawer() {
	$count = ( WC()->cart ) ? WC()->cart->get_cart_contents_count() : 0;
	?>
	<div class="vestige-drawer-root" aria-hidden="true">
		<div class="vestige-scrim vestige-close-cart"></div>
		<aside id="vestige-cart-drawer" class="vestige-drawer" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( 'Shopping cart', 'vestige' ); ?>">
			<div class="vestige-drawer-head">
				<h2 class="display"><?php esc_html_e( 'Cart', 'vestige' ); ?> — <span class="vestige-drawer-count"><?php echo esc_html( (string) $count ); ?></span></h2>
				<button type="button" class="drawer-close vestige-close-cart" aria-label="<?php esc_attr_e( 'Close cart', 'vestige' ); ?>">✕</button>
			</div>
			<div class="vestige-drawer-body">
				<?php echo vestige_drawer_body_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts. ?>
			</div>
		</aside>
	</div>
	<?php
}

/**
 * Keep the header count and drawer body fresh via Woo fragments.
 *
 * @param array $fragments Fragments.
 * @return array
 */
function vestige_cart_fragments( $fragments ) {
	if ( class_exists( 'WooCommerce' ) && WC()->cart ) {
		$count = WC()->cart->get_cart_contents_count();
		$fragments['.vestige-cart-count']  = '<span class="cart-count vestige-cart-count" aria-hidden="true">' . esc_html( (string) $count ) . '</span>';
		$fragments['.vestige-drawer-count'] = '<span class="vestige-drawer-count">' . esc_html( (string) $count ) . '</span>';
		$fragments['.vestige-drawer-body']  = '<div class="vestige-drawer-body">' . vestige_drawer_body_html() . '</div>';
	}
	return $fragments;
}
add_filter( 'woocommerce_add_to_cart_fragments', 'vestige_cart_fragments' );

/**
 * Send the refreshed drawer fragments as JSON (used by theme.js after
 * quantity changes, which Woo's own fragments flow doesn't cover).
 */
function vestige_send_cart_response() {
	WC()->cart->calculate_totals();
	$fragments = vestige_cart_fragments( array() );
	wp_send_json(
		array(
			'fragments' => $fragments,
			'count'     => WC()->cart->get_cart_contents_count(),
		)
	);
}

/**
 * AJAX: change a cart item's quantity from the drawer steppers.
 */
function vestige_ajax_set_qty() {
	check_ajax_referer( 'vestige_cart' );
	if ( ! class_exists( 'WooCommerce' ) || ! WC()->cart ) {
		wp_send_json_error();
	}
	$key   = isset( $_POST['key'] ) ? sanitize_text_field( wp_unslash( $_POST['key'] ) ) : '';
	$delta = isset( $_POST['delta'] ) ? (int) $_POST['delta'] : 0;
	$cart  = WC()->cart;
	if ( $key && isset( $cart->cart_contents[ $key ] ) ) {
		$new = (int) $cart->cart_contents[ $key ]['quantity'] + $delta;
		if ( $new <= 0 ) {
			$cart->remove_cart_item( $key );
		} else {
			$cart->set_quantity( $key, $new, true );
		}
	}
	vestige_send_cart_response();
}
add_action( 'wp_ajax_vestige_set_qty', 'vestige_ajax_set_qty' );
add_action( 'wp_ajax_nopriv_vestige_set_qty', 'vestige_ajax_set_qty' );

/**
 * AJAX: remove a cart item from the drawer.
 */
function vestige_ajax_remove_item() {
	check_ajax_referer( 'vestige_cart' );
	if ( ! class_exists( 'WooCommerce' ) || ! WC()->cart ) {
		wp_send_json_error();
	}
	$key = isset( $_POST['key'] ) ? sanitize_text_field( wp_unslash( $_POST['key'] ) ) : '';
	if ( $key ) {
		WC()->cart->remove_cart_item( $key );
	}
	vestige_send_cart_response();
}
add_action( 'wp_ajax_vestige_remove_item', 'vestige_ajax_remove_item' );
add_action( 'wp_ajax_nopriv_vestige_remove_item', 'vestige_ajax_remove_item' );

/* ---------------------------------------------------------------------------
   Newsletter (footer band + pattern): stores emails in an option —
   no plugin, no third-party service. Buyers can swap the handler for
   their mailing-list provider; see the buyer guide.
   --------------------------------------------------------------------------- */

/**
 * Handle newsletter signups.
 */
function vestige_handle_newsletter() {
	$email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- public signup form, email only.
	$back  = wp_get_referer() ? wp_get_referer() : home_url( '/' );
	if ( is_email( $email ) ) {
		$list = (array) get_option( 'vestige_newsletter_list', array() );
		if ( ! in_array( $email, $list, true ) ) {
			$list[] = $email;
			update_option( 'vestige_newsletter_list', $list, false );
		}
		$back = add_query_arg( 'vestige_subscribed', '1', $back );
	}
	wp_safe_redirect( $back );
	exit;
}
add_action( 'admin_post_vestige_newsletter', 'vestige_handle_newsletter' );
add_action( 'admin_post_nopriv_vestige_newsletter', 'vestige_handle_newsletter' );
