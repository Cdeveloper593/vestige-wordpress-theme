# Vestige — WordPress + WooCommerce Theme

A dark editorial WooCommerce theme for fashion labels and concept stores, ported from the VESTIGE e-commerce template. By **Cerium Web Development**.

- **Drag-and-drop homepage** — every section is a native Gutenberg block pattern (category: *Vestige*). No page-builder plugin, and **no paid plugin anywhere**.
- **Real store** — WooCommerce variable products (Size/Colour), filterable shop (search / category / max price / sort), AJAX cart drawer with a free-shipping meter, WooCommerce checkout.
- **Motion layer** — bundled GSAP + ScrollTrigger + Lenis (free licenses, loaded locally) drive scroll reveals, the marquee, hero treatment, card spotlight/glare and the drawer — all keyed off pattern markup, all gated by `prefers-reduced-motion`, everything readable with JS off.
- **Customizer** — announcement, colours (ink/bone/accent as CSS variables), footer, socials, and the default copy the patterns are seeded with.
- **One-click demo import** — Appearance → Vestige Demo builds the 14-product demo store, idempotently.

## Quick start

1. Install/activate free WooCommerce.
2. Upload `vestige.zip` under Appearance → Themes, activate.
3. Appearance → Vestige Demo → *Import demo store*.
4. Edit Pages → Home (block editor), Products, and Customize → Vestige.

Full buyer guide: `docs/documentation.html`. WordPress.org-style readme: `readme.txt`.

## Requirements

WordPress 6.3+, PHP 7.4+, WooCommerce (free). GPLv2 or later — see `LICENSE`.
