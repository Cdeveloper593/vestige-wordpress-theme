<?php
/**
 * Template tags: small output helpers used across templates.
 *
 * @package Vestige
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Print the site identity mark: custom logo if set, otherwise the
 * wordmark — site title in Anton with a vermilion full stop, exactly
 * like the source template's "VESTIGE." header.
 */
function vestige_the_wordmark() {
	if ( has_custom_logo() ) {
		the_custom_logo();
		return;
	}
	$name = get_bloginfo( 'name' );
	if ( '' === trim( (string) $name ) ) {
		$name = 'VESTIGE';
	}
	echo '<a class="wordmark" href="' . esc_url( home_url( '/' ) ) . '" rel="home" aria-label="' . esc_attr( $name ) . '">';
	echo esc_html( $name ) . '<span class="dot" aria-hidden="true">.</span>';
	echo '</a>';
}

/**
 * Print the header cart button with its count badge. The count span
 * carries the WooCommerce AJAX fragment class so it stays in sync.
 */
function vestige_the_cart_button() {
	$count = 0;
	if ( class_exists( 'WooCommerce' ) && WC()->cart ) {
		$count = WC()->cart->get_cart_contents_count();
	}
	?>
	<button type="button" class="cart-btn vestige-open-cart" aria-haspopup="dialog" aria-controls="vestige-cart-drawer"
		aria-label="<?php echo esc_attr( sprintf( /* translators: %d: items in cart. */ __( 'Cart, %d items', 'vestige' ), $count ) ); ?>">
		<?php esc_html_e( 'Cart', 'vestige' ); ?>
		<span class="cart-count vestige-cart-count" aria-hidden="true"><?php echo esc_html( (string) $count ); ?></span>
	</button>
	<?php
}

/**
 * Breadcrumb trail for product / shop pages, in the source style
 * (Home / Shop / Category / Name, separated by slashes).
 */
function vestige_breadcrumbs() {
	$items = array(
		array( 'label' => __( 'Home', 'vestige' ), 'url' => home_url( '/' ) ),
	);
	if ( class_exists( 'WooCommerce' ) ) {
		$items[] = array( 'label' => __( 'Shop', 'vestige' ), 'url' => vestige_shop_url() );
		if ( is_singular( 'product' ) ) {
			$terms = get_the_terms( get_the_ID(), 'product_cat' );
			if ( $terms && ! is_wp_error( $terms ) ) {
				$link = get_term_link( $terms[0] );
				if ( ! is_wp_error( $link ) ) {
					$items[] = array( 'label' => $terms[0]->name, 'url' => $link );
				}
			}
			$items[] = array( 'label' => get_the_title(), 'url' => '' );
		} elseif ( is_tax( 'product_cat' ) ) {
			$items[] = array( 'label' => single_term_title( '', false ), 'url' => '' );
		}
	}
	echo '<nav class="vestige-crumbs" aria-label="' . esc_attr__( 'Breadcrumb', 'vestige' ) . '">';
	foreach ( $items as $i => $item ) {
		if ( $i > 0 ) {
			echo ' <span aria-hidden="true">/</span> ';
		}
		if ( '' !== $item['url'] ) {
			echo '<a href="' . esc_url( $item['url'] ) . '">' . esc_html( $item['label'] ) . '</a>';
		} else {
			echo '<span class="current">' . esc_html( $item['label'] ) . '</span>';
		}
	}
	echo '</nav>';
}

/**
 * Posted-on line for blog templates.
 */
function vestige_posted_on() {
	printf(
		'<span class="posted-on">%1$s</span>',
		esc_html( get_the_date() )
	);
	if ( get_the_author() ) {
		printf(
			' <span class="byline">%1$s %2$s</span>',
			esc_html__( 'by', 'vestige' ),
			esc_html( get_the_author() )
		);
	}
}
