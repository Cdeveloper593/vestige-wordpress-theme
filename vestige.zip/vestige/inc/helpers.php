<?php
/**
 * Small parsing / formatting helpers shared by templates, the
 * Customizer and the block patterns.
 *
 * @package Vestige
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Wrapper around get_theme_mod() with a Vestige default fallback.
 *
 * @param string $key     Full theme mod key.
 * @param mixed  $default Default when the mod is not set / empty.
 * @return mixed
 */
function vestige_mod( $key, $default = '' ) {
	$value = get_theme_mod( $key, null );
	if ( null === $value || '' === $value ) {
		return $default;
	}
	return $value;
}

/**
 * Free-shipping threshold (USD) — mirrors the source template's
 * FREE_SHIPPING_THRESHOLD and the demo import's shipping zone.
 *
 * @return float
 */
function vestige_free_shipping_threshold() {
	return (float) apply_filters( 'vestige_free_shipping_threshold', 200 );
}

/**
 * The three hero stats from the Customizer.
 *
 * @return array<int, array{value:string,label:string}>
 */
function vestige_hero_stats() {
	$defaults = array(
		1 => array( 'value' => '14', 'label' => 'Pieces' ),
		2 => array( 'value' => '4.8', 'label' => 'Avg rating' ),
		3 => array( 'value' => '2,841', 'label' => 'Reviews' ),
	);
	$stats = array();
	for ( $i = 1; $i <= 3; $i++ ) {
		$stats[] = array(
			'value' => (string) vestige_mod( 'vestige_stat_' . $i . '_value', $defaults[ $i ]['value'] ),
			'label' => (string) vestige_mod( 'vestige_stat_' . $i . '_label', $defaults[ $i ]['label'] ),
		);
	}
	return $stats;
}

/**
 * Parse a "one per line" Customizer textarea into trimmed lines.
 *
 * @param string $raw Raw textarea value.
 * @return string[]
 */
function vestige_lines( $raw ) {
	$lines = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) $raw ) as $line ) {
		$line = trim( $line );
		if ( '' !== $line ) {
			$lines[] = $line;
		}
	}
	return $lines;
}

/**
 * Press / as-seen-in names from the Customizer (one per line).
 *
 * @return string[]
 */
function vestige_press_names() {
	$raw = (string) vestige_mod(
		'vestige_press_names',
		"HYPEBEAST\nGQ\nDAZED\nHIGHSNOBIETY\ni-D"
	);
	return vestige_lines( $raw );
}

/**
 * Category bento tiles: the five demo categories with their source
 * label + blurb. Labels/blurbs are Customizer-editable as
 * "Name | Label | Blurb" lines; product categories that exist on the
 * site but are not listed fall back to a generic tile.
 *
 * @return array<int, array{name:string,label:string,blurb:string,slug:string}>
 */
function vestige_category_tiles() {
	$raw = (string) vestige_mod(
		'vestige_category_tiles',
		implode(
			"\n",
			array(
				'Outerwear | Start here | Leather, wool, weather armour.',
				'Tailoring | Sharp | Blazers, denim, the column dress.',
				'Essentials | Daily | Heavy tees and seamless knits.',
				'Footwear | Ground | Runners, courts, slip-ons.',
				'Objects | Carry | Packs and frames. Nothing extra.',
			)
		)
	);

	$tiles = array();
	foreach ( vestige_lines( $raw ) as $line ) {
		$parts = array_map( 'trim', explode( '|', $line ) );
		if ( '' === $parts[0] ) {
			continue;
		}
		$tiles[] = array(
			'name'  => $parts[0],
			'label' => isset( $parts[1] ) ? $parts[1] : '',
			'blurb' => isset( $parts[2] ) ? $parts[2] : '',
			'slug'  => sanitize_title( $parts[0] ),
		);
	}
	return $tiles;
}

/**
 * URL for a product category archive (shop page when Woo is inactive).
 *
 * @param string $slug Category slug.
 * @return string
 */
function vestige_category_url( $slug ) {
	if ( class_exists( 'WooCommerce' ) ) {
		$term = get_term_by( 'slug', $slug, 'product_cat' );
		if ( $term && ! is_wp_error( $term ) ) {
			$link = get_term_link( $term );
			if ( ! is_wp_error( $link ) ) {
				return $link;
			}
		}
	}
	$shop = function_exists( 'wc_get_page_id' ) ? wc_get_page_id( 'shop' ) : 0;
	return $shop > 0 ? get_permalink( $shop ) : home_url( '/' );
}

/**
 * The shop page URL (home when WooCommerce is inactive).
 *
 * @return string
 */
function vestige_shop_url() {
	if ( class_exists( 'WooCommerce' ) && function_exists( 'wc_get_page_id' ) ) {
		$id = wc_get_page_id( 'shop' );
		if ( $id > 0 ) {
			return get_permalink( $id );
		}
	}
	return home_url( '/' );
}

/**
 * The checkout page URL.
 *
 * @return string
 */
function vestige_checkout_url() {
	if ( class_exists( 'WooCommerce' ) && function_exists( 'wc_get_checkout_url' ) ) {
		return wc_get_checkout_url();
	}
	return home_url( '/' );
}

/**
 * Social links from the Customizer ("Label | URL" lines).
 *
 * @return array<int, array{label:string,url:string}>
 */
function vestige_socials() {
	$raw = (string) vestige_mod(
		'vestige_socials',
		implode(
			"\n",
			array(
				'Instagram | https://instagram.com',
				'Pinterest | https://pinterest.com',
				'TikTok | https://tiktok.com',
			)
		)
	);
	$socials = array();
	foreach ( vestige_lines( $raw ) as $line ) {
		$parts = array_map( 'trim', explode( '|', $line ) );
		if ( count( $parts ) >= 2 && '' !== $parts[0] && '' !== $parts[1] ) {
			$socials[] = array(
				'label' => $parts[0],
				'url'   => $parts[1],
			);
		}
	}
	return $socials;
}

/**
 * Star markup (★ characters) for a rating, matching the source cards.
 *
 * @param float $rating Average rating.
 * @return string HTML (already escaped pieces).
 */
function vestige_stars_html( $rating ) {
	$full = (int) round( (float) $rating );
	$full = max( 0, min( 5, $full ) );
	return '<span class="vestige-stars" aria-hidden="true">' . str_repeat( '★', $full ) . str_repeat( '☆', 5 - $full ) . '</span>';
}
